"""Short Gemini requests with shared-budget protection and durable response caching."""
from __future__ import annotations

import asyncio
import copy
import math
import time

from openai import APIStatusError
from taxonomy_experiment.io import append_jsonl, read_json, write_json
from experiments.taxonomy_contrastive_attribution.runtime import (
    Client as CachedClient, Ledger as BaseLedger, Progress as BaseProgress, StopRun,
)
from experiments.taxonomy_contrastive_attribution.prepare import sha
from experiments.deepseek_step_relation_merge.streaming import collect


class Ledger(BaseLedger):
    def __init__(self,path,cap,prior_path):
        super().__init__(path,cap);self.prior=BaseLedger(prior_path,8)
        if not prior_path.exists():raise StopRun('Prior study ledger is missing; refusing a budget reset')
        prior=self.prior.summary()
        if prior['holds']:raise StopRun('Prior study billing is unresolved')
        if prior['billed']+.000000001<.05774304:raise StopRun('Prior spend is below the recorded baseline')

    def summary(self):
        current=super().summary();prior=self.prior.summary()
        if prior['holds']:raise StopRun('Prior study has unresolved billing')
        current['new_billed']=current['billed'];current['prior_billed']=prior['billed']
        current['billed']+=prior['billed'];current['guard']+=prior['guard']
        return current


class Client(CachedClient):
    def request(self,messages):
        return {**copy.deepcopy(self.config['request']),'messages':messages}

    def fingerprint(self,messages):
        request=self.request(messages)
        return sha(request),request

    def validate(self,raw):
        usage=raw.get('usage') or {}
        if usage.get('is_byok') is not False:raise StopRun('Workspace-credit billing is not explicitly confirmed; saved response retained')
        if raw.get('provider') not in ('Google AI Studio','Google'):
            raise StopRun('Response did not come from the pinned Google route')
        if raw.get('service_tier') not in (None,'default','standard'):
            raise StopRun('Non-standard service tier returned; response retained')
        if raw.get('model') not in ('google/gemini-2.5-flash','gemini-2.5-flash'):
            raise StopRun('Returned model differs from Gemini 2.5 Flash')
        thought=(usage.get('completion_tokens_details') or {}).get('reasoning_tokens')
        if thought != 0:raise StopRun('Zero thinking usage is not confirmed; stopped before more requests')
        cost=usage.get('cost')
        if type(cost) not in (int,float) or not math.isfinite(cost) or cost<0:
            raise StopRun('Authoritative cost missing; reservation retained')

    def audit_cache(self,allowed_keys):
        # A permanently rejected saved response must stop BEFORE any other new request.
        for path in self.cache.glob('*.json'):
            cached=read_json(path);key=sha(cached['request'])
            if key!=path.stem or key not in allowed_keys:raise StopRun('Unplanned or corrupted cached request')
            self.validate(cached['raw_response'])

    def _send(self,request,progress):
        if self.sender:return self.sender(request,progress)
        deadline=self.config['execution_plan']['request_total_deadline_seconds']
        args={'api_key':self.secret,'base_url':'https://openrouter.ai/api/v1',
              'timeout':deadline,'max_retries':0,
              'default_headers':{'X-OpenRouter-Title':'taxonomy-short-attribution'}}
        return asyncio.run(collect(args,request,deadline=deadline,progress=progress)).model_dump(mode='json')

    def _call(self,messages,progress,cancel):
        request=self.request(messages);key=sha(request);path=self.cache/(key+'.json')
        if path.exists():
            cached=read_json(path)
            if cached['request']!=request:raise StopRun('Cached request mismatch')
            self.validate(cached['raw_response']);return cached['raw_response'],key
        limits=self.config['execution_plan'];prices=request['extra_body']['provider']['max_price']
        byte_bound=sum(len(m['content'].encode('utf-8')) for m in messages)+4096
        reserve=(byte_bound*prices['prompt']+request['max_tokens']*prices['completion'])/1e6
        waited=0
        for attempt in range(limits['max_429_retries']+1):
            if cancel.is_set():raise StopRun('Stopped before another request')
            hold=self.ledger.reserve(key,reserve)
            try:raw=self._send(request,progress)
            except APIStatusError as exc:
                code=exc.status_code
                append_jsonl(self.output/'provider_errors.jsonl',{'cache_key':key,'http_status':code,**self.safe_error(exc)})
                if code in (400,401,402,403,404,413,422,429):
                    self.ledger.finish(hold,key)
                    if code!=429:raise StopRun(f'HTTP {code}: request rejected; inspect provider_errors.jsonl. No model failure scored.') from None
                    try:retry=float(exc.response.headers.get('retry-after','0'))
                    except (TypeError,ValueError):retry=0
                    delay=max(15*2**attempt,retry if math.isfinite(retry) else 0)
                    if attempt==limits['max_429_retries'] or waited+delay>limits['max_429_backoff_total_seconds']:
                        raise StopRun('Repeated HTTP 429; bounded cooldown exhausted. Resume the same command later.') from None
                    waited+=delay;progress.emit('RATE_LIMIT',status='WAITING_RATE_LIMIT',retry_seconds=delay)
                    if self.sleeper:self.sleeper(delay)
                    elif cancel.wait(delay):raise StopRun('Stopped during cooldown')
                    progress.update_fields(status='WAITING_API');continue
                raise StopRun(f'HTTP {code}: billing uncertain; reservation retained, no automatic duplicate') from None
            except Exception as exc:
                append_jsonl(self.output/'provider_errors.jsonl',{'cache_key':key,'attempt_id':hold,
                    'generation_id':progress.state.get('generation_id'),**self.safe_error(exc)})
                raise StopRun('Transport/stream failed; billing remains reserved. Inspect provider_errors.jsonl and usage before resuming.') from None
            write_json(path,{'cache_key':key,'request':request,'raw_response':raw})
            cost=(raw.get('usage') or {}).get('cost')
            if type(cost) in (int,float) and math.isfinite(cost) and cost>=0:self.ledger.finish(hold,key,cost)
            self.validate(raw)
            if self.ledger.summary()['guard']>self.ledger.cap:raise StopRun('Reported budget exceeded; all further requests blocked')
            return raw,key


class Progress(BaseProgress):
    def __init__(self,output,ledger,total,calibration,evaluation):
        super().__init__(output,ledger,total,0,total//4)
        self.calibration_target=calibration;self.evaluation_target=evaluation
        self.fields.update(calibration_done=0,evaluation_done=0,invalid_json=0,invalid_axes=0)

    def emit(self,event,**fields):
        from datetime import datetime
        from zoneinfo import ZoneInfo
        with self.lock:
            self.fields.update(fields);s=self.ledger.summary();elapsed=time.monotonic()-self.started
            done=self.fields['calls_done']
            if self.base_done is None:self.base_done=done
            delta=done-self.base_done;eta=f'{elapsed/delta*(self.total-done)/60:.0f}m' if delta else '--'
            active=' | '.join(f'{k} {v.get("status","WAITING_API")} wait={time.monotonic()-v["started"]:.0f}s '
                f'model_chars={v.get("generated_content_chars",0)} reasoning_chars={v.get("generated_reasoning_chars",0)}'
                for k,v in self.workers.items())
            arms=' '.join(f'{k}={v}/{self.per_arm}' for k,v in self.fields['arms'].items())
            stamp=datetime.now(ZoneInfo('Asia/Seoul')).strftime('%H:%M:%S KST')
            line=(f'[{stamp}] [{event}] {self.fields["phase"]} | calls={done}/{self.total} '
                f'cal={self.fields["calibration_done"]}/{self.calibration_target} '
                f'eval={self.fields["evaluation_done"]}/{self.evaluation_target} {arms} '
                f'json_invalid={self.fields["invalid_json"]} invalid_axes={self.fields["invalid_axes"]} | '
                f'billed=${s["billed"]:.4f} (prior=${s.get("prior_billed",0):.4f}) '
                f'reserved=${s["reserved"]:.4f} guard=${s["guard"]:.4f}/${self.ledger.cap:g} | '
                f'elapsed={elapsed/60:.1f}m ETA~{eta} | {active or self.fields.get("message","")}')
            print(line,flush=True)
            write_json(self.output/'progress.json',{**self.fields,'event':event,'elapsed_seconds':elapsed,
                'billing':{k:v for k,v in s.items() if k!='holds'},'workers':self.workers})
            with (self.output/'progress.log').open('a',encoding='utf-8') as f:f.write(line+'\n')
