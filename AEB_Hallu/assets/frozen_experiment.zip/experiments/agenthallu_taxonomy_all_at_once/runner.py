"""Explicit development/evaluation execution, one shared durable $5 budget."""
import hashlib
import importlib.metadata
import json
import os
import threading
import time
from collections import Counter
from concurrent.futures import FIRST_COMPLETED,ThreadPoolExecutor,wait

from taxonomy_experiment.config import _load_project_dotenv
from taxonomy_experiment.io import append_jsonl,read_json,write_json
from experiments.step_accuracy_v2.core import run_lock
from experiments.taxonomy_contrastive_attribution.runner import freeze_files
from experiments.taxonomy_contrastive_attribution.runtime import load_rows
from .design import ROOT,HERE,SOURCE,ARMS,sha,canonical,guidance,messages,parse
from .runtime import Client,Ledger,Progress,StopRun,client_config
from .results import summarize

ARTIFACTS=HERE/'artifacts'


def snapshot():
    plan=read_json(HERE/'study_plan.json')
    for name,digest in plan['hashes'].items():
        if sha((HERE/'prepared'/name).read_bytes())!=digest:raise StopRun('Prepared file changed: '+name)
    if plan['conditions']!=list(ARMS) or plan['budget']['hard_cap_usd']!=5:raise StopRun('Four-condition/$5 protocol changed')
    inf=plan['inference']
    if (inf['model'],inf['reasoning_enabled'],inf['max_output_tokens'],inf['workers'])!=('google/gemini-2.5-flash',False,512,2):
        raise StopRun('The reviewed short Gemini settings changed')
    data=load_rows(HERE/'prepared/inputs.jsonl');manifest=load_rows(HERE/'prepared/request_manifest.jsonl')
    gold=load_rows(HERE/'prepared/gold.jsonl');lookup={r['case_id']:r for r in data}
    if len(lookup)!=275 or len(data)!=275 or {g['case_id'] for g in gold}!=set(lookup) or len(gold)!=275:raise StopRun('Unexpected sample IDs')
    groups=[{r['group_id'] for r in data if r['split']==p} for p in ('development','evaluation')]
    if groups[0]&groups[1] or tuple(map(len,groups))!=(35,240):raise StopRun('Development/evaluation split changed')
    expected=Counter({(r['case_id'],a):1 for r in data for a in (ARMS[:3] if r['split']=='development' else ARMS)})
    if Counter((r['case_id'],r['arm']) for r in manifest)!=expected:raise StopRun('Request manifest changed')
    texts=guidance()[0]
    for a in ARMS:
        if (HERE/'prepared/guidance'/(a+'.txt')).read_text(encoding='utf-8')!=texts[a]:raise StopRun('Guidance differs from source construction')
    for task in manifest:
        if sha(canonical(messages(lookup[task['case_id']],texts[task['arm']])))!=task['prompt_sha256']:raise StopRun('Prepared prompt changed')
    files=[p for p in HERE.glob('*.py') if not p.name.startswith('test_')]+[HERE/'study_plan.json']
    files += [p for p in (HERE/'prepared').rglob('*') if p.is_file()]
    files += [ROOT/p for p in ('taxonomies/agentrx_taxonomy.json','experiments/taxonomy_short_attribution/runtime.py',
        'experiments/taxonomy_contrastive_attribution/runtime.py','experiments/taxonomy_contrastive_attribution/prepare.py',
        'experiments/taxonomy_contrastive_attribution/runner.py','experiments/deepseek_step_relation_merge/streaming.py',
        'experiments/step_accuracy_v2/core.py','src/taxonomy_experiment/config.py','src/taxonomy_experiment/io.py')]
    identity={'version':'agenthallu-taxonomy-runtime-v1',
        'files_sha256':{p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted(files)},
        'packages':{n:importlib.metadata.version(n) for n in ('openai','httpx','pydantic','tiktoken')}}
    return plan,data,manifest,identity


def preflight(phase='development'):
    _load_project_dotenv(ROOT);plan,data,manifest,identity=snapshot();digest=sha(canonical(identity))
    if (ARTIFACTS/'active_run.json').exists() and read_json(ARTIFACTS/'active_run.json')['identity_sha256']!=digest:
        raise StopRun('Active study is frozen to different files; no new budget created')
    ledger=Ledger(ARTIFACTS/'ledger.jsonl',5);spend=ledger.summary()
    if spend['holds']:raise StopRun('Previous request billing is unresolved; do not send duplicates')
    return {'status':'OFFLINE_READY','phase':phase,'api_key_configured':bool(os.environ.get('OPENROUTER_API_KEY')),
        'planned_phase_calls':sum(t['split']==phase for t in manifest),'planned_study_calls':len(manifest),
        'model':plan['inference']['model'],'thinking_enabled':False,'hard_cap_usd':5,'billed_usd':spend['billed'],
        'paid_calls_made_by_check':0,'live_endpoint_validated':False,'identity_sha256':digest}


class Study:
    def __init__(self,plan,data,manifest,output,client,progress,phase,guides):
        self.plan,self.data,self.manifest,self.output,self.client,self.progress,self.phase=plan,data,manifest,output,client,progress,phase
        self.guides=guides;self.lookup={r['case_id']:r for r in data};self.cancel=threading.Event()
        saved=load_rows(output/'predictions.jsonl');self.rows={(r['case_id'],r['arm']):r for r in saved}
        allowed={(r['case_id'],r['arm']):r for r in manifest}
        if len(saved)!=len(self.rows) or self.rows.keys()-allowed.keys():raise StopRun('Duplicate or unexpected saved predictions')
        for key,row in self.rows.items():
            if row['prompt_sha256']!=allowed[key]['prompt_sha256']:raise StopRun('Saved prediction belongs to a different prompt')
        self.refresh()

    def refresh(self):
        rows=[r for r in self.rows.values() if r['split']==self.phase]
        self.progress.update(calls_done=len(rows),overall_done=len(self.rows),arms=dict(Counter(r['arm'] for r in rows)),
            invalid_json=sum(not r['json_valid'] for r in rows),
            invalid_coordinates=sum('invalid_native_step' in (r['prediction'] or {}).get('format_issues',[]) for r in rows),
            field_issues=sum(bool((r['prediction'] or {}).get('format_issues',[])) for r in rows))

    def one(self,task):
        record=self.lookup[task['case_id']];prompt=messages(record,self.guides[task['arm']])
        if sha(canonical(prompt))!=task['prompt_sha256']:raise StopRun('Frozen prompt mismatch')
        worker=self.progress.worker(task['case_id']+':'+task['arm']);started=time.monotonic()
        try:
            raw,key=self.client.call(prompt,worker,self.cancel)
            row={**task,'cache_key':key,'json_valid':False,'prediction':None,'api_seconds':time.monotonic()-started,'usage':raw.get('usage') or {}}
            try:
                choice=raw['choices'][0]
                if choice.get('finish_reason')!='stop':raise ValueError('Truncated/non-stop output')
                row['prediction']=parse(json.loads(choice['message'].get('content') or ''),record);row['json_valid']=True
            except (ValueError,TypeError,KeyError,IndexError) as exc:row['parse_error']=str(exc)[:250]
            return row
        finally:worker.close()

    def stage(self):
        tasks=iter(t for t in self.manifest if t['split']==self.phase and (t['case_id'],t['arm']) not in self.rows)
        stopped=None
        with ThreadPoolExecutor(max_workers=2) as pool:
            pending={}
            def submit():
                task=next(tasks,None)
                if task is None:return
                if time.monotonic()-self.progress.started>=3600:raise StopRun('One-hour dispatch limit; saved work retained for resume')
                pending[pool.submit(self.one,task)]=task
            for _ in range(2):submit()
            while pending:
                try:done,_=wait(pending,return_when=FIRST_COMPLETED)
                except BaseException as exc:stopped=exc;self.cancel.set();done=set(pending)
                for future in sorted(done,key=lambda f:pending[f]['order']):
                    pending.pop(future)
                    try:
                        row=future.result();append_jsonl(self.output/'predictions.jsonl',row)
                        self.rows[row['case_id'],row['arm']]=row;self.refresh()
                        self.progress.emit('SAVED',message=row['case_id']+':'+row['arm'])
                    except BaseException as exc:
                        if stopped is None:stopped=exc
                        self.cancel.set()
                if stopped is None:
                    for _ in done:
                        try:submit()
                        except BaseException as exc:stopped=exc;self.cancel.set();break
        if stopped is not None:raise stopped


def run(phase='development'):
    _load_project_dotenv(ROOT);ARTIFACTS.mkdir(exist_ok=True)
    with run_lock(ARTIFACTS/'budget.lock'):
        plan,data,manifest,identity=snapshot();digest=sha(canonical(identity))
        if not os.environ.get('OPENROUTER_API_KEY'):raise StopRun('OPENROUTER_API_KEY missing from project .env or environment')
        active=ARTIFACTS/'active_run.json';output=ARTIFACTS/('run-'+digest[:16])
        if active.exists():
            if read_json(active)['identity_sha256']!=digest:raise StopRun('Active study files changed; refusing a fresh run/budget')
        else:
            if (ARTIFACTS/'ledger.jsonl').exists():raise StopRun('Ledger without active identity; refusing budget reset')
            if phase!='development':raise StopRun('Complete development first; evaluation cannot start a new study')
            output.mkdir(exist_ok=True);write_json(output/'identity.json',identity)
            write_json(active,{'identity_sha256':digest,'run_directory':str(output)})
        freeze_files(identity,output)
        ledger=Ledger(ARTIFACTS/'ledger.jsonl',5);client=Client(client_config(plan),output,ledger)
        frozen=output/'frozen/experiments/agenthallu_taxonomy_all_at_once/prepared'
        data=load_rows(frozen/'inputs.jsonl');manifest=load_rows(frozen/'request_manifest.jsonl')
        texts={a:(frozen/'guidance'/(a+'.txt')).read_text(encoding='utf-8') for a in ARMS}
        progress=Progress(output,ledger,phase,dict(Counter(t['arm'] for t in manifest if t['split']==phase)),len(manifest))
        try:
            ledger.recover(client.cache)
            study=Study(plan,data,manifest,output,client,progress,phase,texts)
            client.audit_cache({client.fingerprint(messages(study.lookup[t['case_id']],texts[t['arm']]))[0] for t in manifest})
            if phase=='evaluation':
                if any((t['case_id'],t['arm']) not in study.rows for t in manifest if t['split']=='development'):
                    raise StopRun('Development incomplete; evaluation not started')
            progress.start();progress.emit('START',status='RUNNING',message='Gemini 2.5 Flash, thinking off, workspace credits, shared study cap $5')
            study.stage()
            report=summarize(plan,data,load_rows(frozen/'gold.jsonl'),study.rows,manifest,phase,output,ledger)
            status=report['status'];result={'status':status,'phase':phase,'run_directory':str(output),
                'result_file':str(output/(phase.upper()+'_RESULTS.md')),'billed_usd':ledger.summary()['billed'],
                'evaluation_started_automatically':False}
            write_json(output/'status.json',result)
            progress.emit(status,status=status,message=result['result_file'])
            return result
        except BaseException as exc:
            reason=str(exc) if isinstance(exc,StopRun) else ('Interrupted by user; saved in-flight work retained' if isinstance(exc,KeyboardInterrupt) else type(exc).__name__+'; inspect saved logs')
            write_json(output/'status.json',{'status':'STOPPED','phase':phase,'reason':reason})
            progress.emit('STOPPED',status='STOPPED',message=reason)
            raise StopRun(reason) from None
        finally:
            progress.stop.set()
            if progress.thread.is_alive():progress.close()
