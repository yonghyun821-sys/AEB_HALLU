"""Use the existing audited streaming/cache client with this study's ledger."""
import time
from datetime import datetime
from zoneinfo import ZoneInfo

from taxonomy_experiment.io import write_json
from experiments.taxonomy_contrastive_attribution.runtime import Ledger, Progress as BaseProgress, StopRun
from experiments.taxonomy_short_attribution.runtime import Client


def client_config(plan):
    inference=plan['inference']
    return {'request':{'model':inference['model'],'temperature':inference['temperature'],
        'max_tokens':inference['max_output_tokens'],'response_format':{'type':'json_object'},
        'extra_body':{'reasoning':{'enabled':False},'provider':{
            'only':['google-ai-studio'],'ignore':['google-ai-studio/flex','google-ai-studio/priority'],
            'allow_fallbacks':False,'require_parameters':True,
            'max_price':{'prompt':.30,'completion':2.50,'request':0}}}},
        'execution_plan':{'request_total_deadline_seconds':120,
            'max_429_retries':1,'max_429_backoff_total_seconds':30}}


class Progress(BaseProgress):
    def __init__(self,output,ledger,phase,targets,overall_total):
        super().__init__(output,ledger,sum(targets.values()),0,0)
        self.phase,self.targets,self.overall_total=phase,targets,overall_total
        self.fields.update(phase=phase,overall_done=0,invalid_json=0,invalid_coordinates=0,field_issues=0)

    def emit(self,event,**fields):
        with self.lock:
            self.fields.update(fields);s=self.ledger.summary();elapsed=time.monotonic()-self.started
            done=self.fields['calls_done']
            if self.base_done is None:self.base_done=done
            delta=done-self.base_done
            eta=f'{elapsed/delta*max(0,self.total-done)/60:.1f}m' if delta else '--'
            arms=' '.join(f'{a}={self.fields["arms"].get(a,0)}/{n}' for a,n in self.targets.items())
            active=' | '.join(f'{key} {state.get("status","WAITING_API")} '
                f'wait={time.monotonic()-state["started"]:.0f}s '
                f'model_chars={state.get("generated_content_chars",0)} reasoning_chars={state.get("generated_reasoning_chars",0)}'
                for key,state in self.workers.items())
            line=(f'[{datetime.now(ZoneInfo("Asia/Seoul")).strftime("%H:%M:%S KST")}] [{event}] '
                f'{self.phase} | calls={done}/{self.total} overall={self.fields["overall_done"]}/{self.overall_total} '
                f'{arms} json_invalid={self.fields["invalid_json"]} invalid_step={self.fields["invalid_coordinates"]} field_issues={self.fields["field_issues"]} | '
                f'billed=${s["billed"]:.4f} reserved=${s["reserved"]:.4f} guard=${s["guard"]:.4f}/${self.ledger.cap:g} | '
                f'elapsed={elapsed/60:.1f}m ETA~{eta} | {active or self.fields.get("message","")}')
            print(line,flush=True)
            write_json(self.output/'progress.json',{**self.fields,'event':event,'elapsed_seconds':elapsed,
                'billing':{k:v for k,v in s.items() if k!='holds'},'workers':self.workers,
                'character_counts_are_not_tokens':True})
            with (self.output/'progress.log').open('a',encoding='utf-8') as stream:stream.write(line+'\n')
