"""Phase-specific native When and derived speaker reports, no accuracy gates."""
import csv
import math
import random
import statistics

from taxonomy_experiment.io import write_json
from .design import score
from .runtime import StopRun


def summarize(plan,data,gold,rows,manifest,phase,output,ledger):
    selected=[r for r in data if r['split']==phase]
    arms=plan['conditions'][:3] if phase=='development' else plan['conditions']
    if any((r['case_id'],arm) not in rows for r in selected for arm in arms):
        raise StopRun('Phase incomplete; no final phase accuracy report generated')
    labels={g['case_id']:g for g in gold}
    hits={(r['case_id'],a):score(rows[r['case_id'],a]['prediction'],labels[r['case_id']]) for r in selected for a in arms}
    eligible=sum(labels[r['case_id']]['speaker_eligible'] for r in selected)
    conditions={a:{'n':len(selected),'when_correct':sum(hits[r['case_id'],a]['when'] for r in selected),
        'speaker_n':eligible,'derived_speaker_correct':sum(hits[r['case_id'],a]['derived_speaker'] is True for r in selected),
        'invalid_json':sum(not rows[r['case_id'],a]['json_valid'] for r in selected),
        'field_issues':sum(bool((rows[r['case_id'],a]['prediction'] or {}).get('format_issues',[])) for r in selected)} for a in arms}
    pairs=[('own','foreign')]+([('merged','own')] if phase=='evaluation' else [])
    contrasts=[];rng=random.Random(20261102)
    for left,right in pairs:
        differences=[int(hits[r['case_id'],left]['when'])-int(hits[r['case_id'],right]['when']) for r in selected]
        improved=differences.count(1);regressed=differences.count(-1);discordant=improved+regressed
        p=min(1.0,2*sum(math.comb(discordant,k) for k in range(min(improved,regressed)+1))/(2**discordant)) if discordant else 1.0
        boots=sorted(100*sum(rng.choices(differences,k=len(differences)))/len(differences) for _ in range(10000))
        contrasts.append({'contrast':left+' - '+right,'when_delta_pp':100*sum(differences)/len(differences),
            'improved':improved,'regressed':regressed,'paired_bootstrap_95_percent_pp':[boots[249],boots[9749]],'mcnemar_p':p})
    previous=0
    for rank,index in enumerate(sorted(range(len(contrasts)),key=lambda i:contrasts[i]['mcnemar_p'])):
        previous=max(previous,min(1,(len(contrasts)-rank)*contrasts[index]['mcnemar_p']))
        contrasts[index]['holm_p']=previous
    baselines={name:sum(r['native_steps'][offset]==labels[r['case_id']]['hallucination_step'] for r in selected)
        for name,offset in [('first',0),('last',-1),('penultimate',-2)]}
    by_framework={fw:{a:{'n':sum(r['framework']==fw for r in selected),
        'when_correct':sum(hits[r['case_id'],a]['when'] for r in selected if r['framework']==fw)} for a in arms}
        for fw in sorted({r['framework'] for r in selected})}
    phase_rows=[r for r in rows.values() if r['split']==phase]
    remaining=[r for r in manifest if (r['case_id'],r['arm']) not in rows]
    ratios=[];completion=[];latency=[]
    for row in phase_rows:
        usage=row['usage'];prompt=usage.get('prompt_tokens');out=usage.get('completion_tokens')
        if type(prompt) is int and prompt>0 and type(out) is int and out>=0:
            ratios.append(prompt/row['input_proxy_tokens']);completion.append(out);latency.append(row['api_seconds'])
    spend={k:v for k,v in ledger.summary().items() if k!='holds'}
    resource={'billed_usd':spend['billed'],'remaining_calls':len(remaining),'accuracy_used_as_gate':False}
    if len(ratios)==len(phase_rows) and ratios:
        factor=max(1.35,max(ratios))*1.05
        out_bound=min(512,max(200,statistics.mean(completion)+2*statistics.pstdev(completion)))
        resource.update(input_proxy_multiplier=factor,output_planning_tokens=out_bound,
            projected_total_cost_usd=spend['guard']+sum(r['input_proxy_tokens'] for r in remaining)*factor*.30/1e6+len(remaining)*out_bound*2.50/1e6,
            projected_remaining_minutes=len(remaining)*statistics.mean(latency)/plan['inference']['workers']/60)
    else:resource['usage_projection_unavailable']=True
    report={'status':phase.upper()+'_COMPLETE','phase':phase,'conditions':conditions,'when_contrasts':contrasts,
        'by_framework':by_framework,'position_baselines_correct':baselines,'billing':spend,'resources':resource,
        'speaker_metric':'derived from annotated step; not independent Who gold','accuracy_gate_used':False,
        'evaluation_started_automatically':False,'independent_merge_semantic_review':False}
    stem=phase.upper()+'_RESULTS'
    write_json(output/(stem+'.json'),report)
    write_json(output/'resource_projection.json',resource)
    lines=[f'# AgentHallu {phase} results','',f'{len(selected)} questions; native exact When. No What or joint score.','',
        '| Condition | When | Derived speaker | Invalid JSON | Field issues |','|---|---:|---:|---:|---:|']
    for arm,c in conditions.items():
        speaker=f'{100*c["derived_speaker_correct"]/eligible:.2f}% ({c["derived_speaker_correct"]}/{eligible})' if eligible else 'N/A'
        lines.append(f'| {arm} | {100*c["when_correct"]/c["n"]:.2f}% ({c["when_correct"]}/{c["n"]}) | {speaker} | {c["invalid_json"]} | {c["field_issues"]} |')
    lines+=['','Derived speaker uses the actor at the annotated step, not independently annotated responsibility.','']
    for c in contrasts:
        lo,hi=c['paired_bootstrap_95_percent_pp']
        lines.append(f'- {c["contrast"]}: {c["when_delta_pp"]:+.2f} pp; paired 95% CI [{lo:+.2f}, {hi:+.2f}]; improved={c["improved"]}, regressed={c["regressed"]}; Holm p={c["holm_p"]:.4g}.')
    lines+=['',f'Billed across this study: ${spend["billed"]:.4f} / $5. No accuracy threshold was used.','']
    if phase=='development':lines+=['Development is complete. Main evaluation has NOT started. Review the basic contrasts, input validity and resource_projection.json before separately starting evaluation.','Do not select new questions or regenerate failures to obtain the desired ranking.','']
    else:lines+=['These are results on the fixed 240-question research subset, not a full AgentHallu leaderboard score.','Merged is a source-preserving guidance package; no simple-union control was run.','']
    lines+=['| Framework | Condition | N | When |','|---|---|---:|---:|']
    for fw,values in by_framework.items():
        for a,c in values.items():lines.append(f'| {fw} | {a} | {c["n"]} | {100*c["when_correct"]/c["n"]:.2f}% |')
    lines+=['',f'Zero-call baselines: '+', '.join(f'{k}={v}/{len(selected)}' for k,v in baselines.items())+'.','']
    (output/(stem+'.md')).write_text('\n'.join(lines),encoding='utf-8')
    with (output/(phase+'_per_case.csv')).open('w',encoding='utf-8',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['case_id','framework','arm','when_correct','derived_speaker_correct'])
        for r in selected:
            for a in arms:writer.writerow([r['case_id'],r['framework'],a,hits[r['case_id'],a]['when'],hits[r['case_id'],a]['derived_speaker']])
    return report
