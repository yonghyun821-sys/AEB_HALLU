from __future__ import annotations

import math
import random
import statistics
from collections import defaultdict

from .data import CONDITIONS, DATASETS

CONTRASTS = (("own", "no_label"), ("foreign", "no_label"),
             ("merged", "no_label"), ("merged", "foreign"), ("merged", "own"))
mean = statistics.mean


def score_predictions(inputs: list[dict], gold: list[dict], predictions: list[dict]) -> list[dict]:
    def index_unique(rows: list[dict], fields: tuple[str, ...]) -> dict:
        index = {}
        for row in rows:
            key = tuple(row[name] for name in fields)
            if key in index:
                raise ValueError(f"Duplicate record: {key}")
            index[key] = row
        return index

    records = index_unique(inputs, ("dataset", "trajectory_id"))
    targets = index_unique(gold, ("dataset", "trajectory_id"))
    outputs = index_unique(predictions, ("dataset", "trajectory_id", "condition"))
    planned = {(*key, condition) for key in records for condition in CONDITIONS}
    if records.keys() != targets.keys():
        raise ValueError("Input/gold keys differ")
    if outputs.keys() != planned:
        raise ValueError(f"Incomplete or unexpected predictions: missing={len(planned - outputs.keys())}, "
                         f"unexpected={len(outputs.keys() - planned)}")
    scored = []
    for key in sorted(planned):
        record, target, prediction = records[key[:2]], targets[key[:2]], outputs[key]
        candidates = record["candidate_step_ids"]
        if not candidates or len(candidates) != len(set(candidates)):
            raise ValueError("Invalid candidate list")
        reference = target["gold_step_id"]
        if reference not in candidates:
            raise ValueError("Gold step not visible")
        predicted = prediction.get("predicted_step_id")
        valid = prediction.get("status") == "ok" and predicted in candidates
        distance = abs(candidates.index(predicted) - candidates.index(reference)) if valid else None
        scored.append({
            "dataset": key[0], "trajectory_id": key[1], "condition": key[2],
            "task_hash": record["task_hash"], "domain": record["domain"],
            "candidate_count": len(candidates), "primary_eligible": len(candidates) >= 2,
            "gold_step_id": reference, "native_gold_step_id": target["native_gold_step_id"],
            "predicted_step_id": predicted, "valid": bool(valid),
            "exact": int(valid and predicted == reference),
            "within_one": int(distance is not None and distance <= 1), "rank_error": distance,
            "gold_at_first": reference == candidates[0], "gold_at_last": reference == candidates[-1],
            "uniform_chance": 1 / len(candidates),
        })
    return scored


def task_vectors(rows: list[dict]) -> list[list[float]]:
    groups = defaultdict(lambda: defaultdict(list))
    for row in rows:
        groups[row["task_hash"]][row["condition"]].append(row["exact"])
    return [[mean(groups[task][condition]) for condition in CONDITIONS] for task in sorted(groups)]


def percentile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    pos = (len(ordered) - 1) * probability
    low, high = math.floor(pos), math.ceil(pos)
    return ordered[low] + (ordered[high] - ordered[low]) * (pos - low)


def holm(p_values: list[float]) -> list[float]:
    result, running = [0.0] * len(p_values), 0.0
    for rank, index in enumerate(sorted(range(len(p_values)), key=p_values.__getitem__)):
        running = max(running, min(1.0, (len(p_values) - rank) * p_values[index]))
        result[index] = running
    return result


def summarize(scored: list[dict], *, resamples: int, seed: int) -> dict:
    if resamples < 100:
        raise ValueError("Use at least 100 resamples")
    primary = [row for row in scored if row["primary_eligible"]]
    vectors = {d: task_vectors([r for r in primary if r["dataset"] == d]) for d in DATASETS}
    if any(not v for v in vectors.values()):
        raise ValueError("Both datasets need nontrivial tasks")
    scopes = (*DATASETS, "dataset_macro")
    point = {d: [mean(row[i] for row in vectors[d]) for i in range(4)] for d in DATASETS}
    point["dataset_macro"] = [mean(point[d][i] for d in DATASETS) for i in range(4)]
    bootstrap = {d: [] for d in scopes}
    rng = random.Random(seed)
    for _ in range(resamples):
        for dataset in DATASETS:
            rows = vectors[dataset]
            sample = [rows[rng.randrange(len(rows))] for _ in rows]
            bootstrap[dataset].append([sum(row[i] for row in sample) / len(sample) for i in range(4)])
        bootstrap["dataset_macro"].append([
            mean(bootstrap[d][-1][i] for d in DATASETS) for i in range(4)])
    summaries, comparisons = [], []
    for dataset in scopes:
        for i, condition in enumerate(CONDITIONS):
            values = [row[i] for row in bootstrap[dataset]]
            summaries.append({"dataset": dataset, "condition": condition,
                              "n_trajectories": sum(r["condition"] == condition and
                                                    (dataset == "dataset_macro" or r["dataset"] == dataset)
                                                    for r in primary),
                              "n_tasks": sum(len(vectors[d]) for d in
                                             (DATASETS if dataset == "dataset_macro" else (dataset,))),
                              "task_balanced_exact_accuracy": point[dataset][i],
                              "ci_low": percentile(values, .025), "ci_high": percentile(values, .975)})
        for after, before in CONTRASTS:
            a, b = CONDITIONS.index(after), CONDITIONS.index(before)
            estimate = point[dataset][a] - point[dataset][b]
            diffs = [row[a] - row[b] for row in bootstrap[dataset]]
            involved = DATASETS if dataset == "dataset_macro" else (dataset,)
            effects = [(row[a] - row[b]) / len(vectors[d]) / len(involved)
                       for d in involved for row in vectors[d]]
            nonzero = [v for v in effects if v]
            if len(nonzero) <= 16:
                nulls = [sum(v if bits & (1 << i) else -v for i, v in enumerate(nonzero))
                         for bits in range(1 << len(nonzero))]
                p = sum(abs(v) >= abs(estimate) - 1e-12 for v in nulls) / len(nulls)
            else:
                hits = sum(abs(sum(v if rng.getrandbits(1) else -v for v in nonzero))
                           >= abs(estimate) - 1e-12 for _ in range(resamples))
                p = (hits + 1) / (resamples + 1)
            comparisons.append({"dataset": dataset, "after": after, "before": before,
                                "accuracy_delta": estimate, "ci_low": percentile(diffs, .025),
                                "ci_high": percentile(diffs, .975), "task_sign_flip_p": p})
    for row, adjusted in zip(comparisons, holm([r["task_sign_flip_p"] for r in comparisons]), strict=True):
        row["holm_p_all_15_contrasts"] = adjusted
    diagnostics = []
    strata = {"all": lambda r: True, "nontrivial": lambda r: r["primary_eligible"],
              "single_candidate": lambda r: not r["primary_eligible"],
              "gold_last": lambda r: r["primary_eligible"] and r["gold_at_last"],
              "gold_not_last": lambda r: r["primary_eligible"] and not r["gold_at_last"]}
    for dataset in DATASETS:
        for stratum, predicate in strata.items():
            subset = [r for r in scored if r["dataset"] == dataset and predicate(r)]
            tv = task_vectors(subset)
            for i, condition in enumerate(CONDITIONS):
                rows = [r for r in subset if r["condition"] == condition]
                if not rows:
                    continue
                distances = [r["rank_error"] for r in rows if r["rank_error"] is not None]
                diagnostics.append({"dataset": dataset, "stratum": stratum, "condition": condition,
                                    "n": len(rows), "tasks": len(tv), "correct": sum(r["exact"] for r in rows),
                                    "row_exact_accuracy": mean(r["exact"] for r in rows),
                                    "task_exact_accuracy": mean(v[i] for v in tv),
                                    "within_one_accuracy": mean(r["within_one"] for r in rows),
                                    "invalid_or_failed": sum(not r["valid"] for r in rows),
                                    "mean_rank_error_valid_only": mean(distances) if distances else None,
                                    "uniform_chance": mean(r["uniform_chance"] for r in rows),
                                    "always_first": mean(r["gold_at_first"] for r in rows),
                                    "always_last": mean(r["gold_at_last"] for r in rows)})
    return {"primary": summaries, "contrasts": comparisons, "diagnostics": diagnostics}
