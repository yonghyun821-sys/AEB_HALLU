from __future__ import annotations

import hashlib
import json
from collections import Counter, defaultdict
from copy import deepcopy
from pathlib import Path
from typing import Any

from taxonomy_experiment.datasets.agentrx import load_agentrx
from taxonomy_experiment.datasets.agenterrorbench import load_agenterrorbench
from taxonomy_experiment.io import iter_jsonl, read_json, write_json, write_jsonl
from taxonomy_experiment.token_count import TokenCounter

DATASETS = ("agentrx", "agenterrorbench")
CONDITIONS = ("no_label", "own", "foreign", "merged")


def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=True, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def step_id(value: Any) -> str:
    if value is None or isinstance(value, bool):
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def freeze(path: Path, value: Any) -> None:
    if path.exists():
        observed = list(iter_jsonl(path)) if path.suffix == ".jsonl" else read_json(path)
        if observed != value:
            raise ValueError(f"Frozen artifact differs; use a new experiment directory: {path}")
    elif path.suffix == ".jsonl":
        write_jsonl(path, value)
    else:
        write_json(path, value)


def normalize_record(source: dict, reference: dict) -> tuple[dict, dict]:
    """Derive candidates from visible data before mapping the official gold ID."""
    dataset = source["dataset"]
    if dataset not in DATASETS:
        raise ValueError("Unknown dataset")
    task = str(source.get("instruction") or "").strip()
    if not task:
        raise ValueError("missing_task")
    native_ids = [step_id(s.get("index")) for s in source["steps"]]
    if not native_ids or any(not s for s in native_ids) or len(set(native_ids)) != len(native_ids):
        raise ValueError("invalid_candidates")
    candidates = [f"S{i:04d}" for i in range(1, len(native_ids) + 1)]
    visible = []
    for candidate, step in zip(candidates, source["steps"], strict=True):
        if "raw_events" in step:
            content = {"events": step["raw_events"]}
        elif dataset == "agentrx":
            content = {"events": [{"role": sub["role"], "content": sub["content"]}
                                   for sub in step["substeps"]]}
        else:
            content = {key: step.get(key, "") for key in
                       ("observation", "available_actions", "agent_output")}
        visible.append({"step_id": candidate, **content})
    native_gold = step_id(reference.get("critical_failure_step"))
    if native_gold not in native_ids:
        raise ValueError("gold_step_not_visible")
    record = {
        "dataset": dataset, "trajectory_id": source["trajectory_id"],
        "domain": source["domain"], "task": task,
        "task_hash": digest(" ".join(task.split()).casefold()),
        "context": source.get("context") or {},
        "steps": visible, "candidate_step_ids": candidates,
    }
    gold = {"dataset": dataset, "trajectory_id": source["trajectory_id"],
            "gold_step_id": candidates[native_ids.index(native_gold)],
            "native_gold_step_id": native_gold, "native_step_ids": native_ids}
    return record, gold


def compact_record(record: dict, counter: TokenCounter) -> dict:
    """Share exact repeated lines; every event remains byte-for-byte reconstructible."""
    texts = [event["content"] for step in record["steps"] for event in step.get("events", [])
             if isinstance(event.get("content"), str)]
    counts = Counter(line for text in texts for line in text.splitlines(keepends=True) if len(line) >= 128)
    shared = {line: f"T{i:04d}" for i, line in enumerate(line for line, n in counts.items() if n >= 2)}
    if not shared:
        return record
    result = deepcopy(record)
    result["shared_text"] = {ref: line for line, ref in shared.items()}
    for step in result["steps"]:
        for event in step.get("events", []):
            if not isinstance(event.get("content"), str):
                continue
            original, parts = event["content"], []
            for line in original.splitlines(keepends=True):
                if line in shared:
                    parts.append({"ref": shared[line]})
                elif parts and isinstance(parts[-1], str):
                    parts[-1] += line
                else:
                    parts.append(line)
            restored = "".join(p if isinstance(p, str) else result["shared_text"][p["ref"]] for p in parts)
            if restored != original:
                raise ValueError("Lossless text reconstruction failed")
            event["content_parts"] = parts
            del event["content"]
    if counter.count(json.dumps(result, ensure_ascii=False)) >= counter.count(json.dumps(record, ensure_ascii=False)):
        return record
    return result


def select_pilot(inputs: list[dict], per_dataset: int, seed: int) -> list[dict]:
    """One representative per task; round-robin domains; no outcomes/gold access."""
    selected = []
    for dataset in DATASETS:
        tasks, domains = {}, defaultdict(list)
        eligible = [r for r in inputs if r["dataset"] == dataset and len(r["steps"]) >= 2]
        for row in sorted(eligible, key=lambda r: digest([seed, dataset, r["trajectory_id"]])):
            tasks.setdefault(row["task_hash"], row)
        for row in tasks.values():
            domains[row["domain"]].append(row)
        if len(tasks) < per_dataset:
            raise ValueError(f"Not enough unique nontrivial {dataset} tasks: {len(tasks)} < {per_dataset}")
        subset = []
        while len(subset) < per_dataset:
            for domain in sorted(domains):
                if domains[domain] and len(subset) < per_dataset:
                    subset.append(domains[domain].pop(0))
        selected.extend(subset)
    return sorted(selected, key=lambda r: (r["dataset"], r["trajectory_id"]))


def prepare(root: Path, output: Path, *, visible_token_limit: int = 900_000,
            compact_shared_lines: bool = False, pilot_per_dataset: int | None = None,
            seed: int = 20261026) -> dict:
    rx = load_agentrx(root / "datasets/agentrx/tau_retail_dataset.jsonl",
                     root / "datasets/agentrx/tau_retail.jsonl",
                     root / "datasets/agentrx/magentic_dataset.jsonl",
                     root / "datasets/agentrx/magentic_one.jsonl", root)
    ae = load_agenterrorbench(root / "datasets/agenterrorbench/Original_Failure_Trajectory",
                             root / "datasets/agenterrorbench/Label", root)
    inputs, gold, audits = [], [], {}
    counter = TokenCounter.for_model("google/gemini-2.5-flash", "o200k_base")
    if counter._encoding is None:
        raise RuntimeError("The configured tokenizer is required for reproducible eligibility")
    for dataset, (sources, references, _) in zip(DATASETS, (rx, ae), strict=True):
        source_index = {row["trajectory_id"]: row for row in sources}
        if len(source_index) != len(sources):
            raise ValueError("Duplicate source trajectory")
        exclusions, normalization = [], Counter()
        for reference in references:
            source = source_index[reference["trajectory_id"]]
            if dataset == "agenterrorbench":
                # Keep actual memory states and complete observations. The legacy
                # loader removes memory wrappers and compacts binary observations.
                raw = read_json(root / source["metadata"]["source_file"])
                messages = raw.get("messages", raw.get("chat_history", []))
                groups = []
                for message in messages:
                    if message["role"] == "user":
                        groups.append([])
                    if not groups:
                        raise ValueError("Unexpected messages before first visible step")
                    groups[-1].append({"role": message["role"], "content": message["content"]})
                if len(groups) != len(source["steps"]):
                    raise ValueError("Raw/normalized step mapping differs")
                source = {**source, "steps": [{"index": step["index"], "raw_events": events}
                          for step, events in zip(source["steps"], groups, strict=True)]}
            try:
                record, target = normalize_record(source, reference)
            except ValueError as exc:
                exclusions.append({"trajectory_id": reference["trajectory_id"], "reason": str(exc)})
                continue
            if compact_shared_lines:
                record = compact_record(record, counter)
            if counter.count(json.dumps(record, ensure_ascii=False)) > visible_token_limit:
                exclusions.append({"trajectory_id": record["trajectory_id"],
                                   "reason": "visible_input_exceeds_fixed_token_limit"})
                continue
            inputs.append(record)
            gold.append(target)
            normalization["memory_blocks_removed"] += 0
            normalization["observation_characters_omitted"] += 0
        subset = [row for row in inputs if row["dataset"] == dataset]
        nontrivial = [row for row in subset if len(row["steps"]) >= 2]
        audits[dataset] = {
            "matched_annotations": len(references), "included": len(subset),
            "primary_nontrivial": len(nontrivial), "single_candidate": len(subset) - len(nontrivial),
            "unique_tasks": len({row["task_hash"] for row in subset}),
            "primary_unique_tasks": len({row["task_hash"] for row in nontrivial}),
            "domains": dict(Counter(row["domain"] for row in subset)),
            "exclusions": exclusions, "source_normalization": dict(normalization),
        }
    if pilot_per_dataset is not None:
        input_pool = inputs
        inputs = select_pilot(input_pool, pilot_per_dataset, seed)
        keep = {(r["dataset"], r["trajectory_id"]) for r in inputs}
        gold = [r for r in gold if (r["dataset"], r["trajectory_id"]) in keep]
        for dataset in DATASETS:
            subset = [r for r in inputs if r["dataset"] == dataset]
            audits[dataset]["eligible_pool_before_sampling"] = audits[dataset]["included"]
            audits[dataset].update(included=len(subset), primary_nontrivial=len(subset), single_candidate=0,
                                    unique_tasks=len(subset), primary_unique_tasks=len(subset),
                                    domains=dict(Counter(r["domain"] for r in subset)))
    inputs.sort(key=lambda row: (row["dataset"], row["trajectory_id"]))
    gold.sort(key=lambda row: (row["dataset"], row["trajectory_id"]))
    keys = [(row["dataset"], row["trajectory_id"]) for row in inputs]
    if len(keys) != len(set(keys)):
        raise ValueError("Duplicate input/gold pair")
    manifest = {"version": 2, "conditions": list(CONDITIONS), "datasets": audits,
                "total_trajectories": len(inputs), "planned_predictions": len(inputs) * 4,
                "inputs_sha256": digest(inputs), "gold_sha256": digest(gold),
                "eligibility": "visible official step only; no category-validity filter",
                "visible_token_limit": visible_token_limit,
                "compact_shared_lines": compact_shared_lines,
                "pilot_per_dataset": pilot_per_dataset,
                "sampling_seed": seed,
                "primary": "candidate_count >= 2; task means within dataset, then equal dataset mean",
                "candidate_policy": "opaque IDs in original visible order; no gold-derived candidates"}
    freeze(output / "inputs.jsonl", inputs)
    freeze(output / "gold.jsonl", gold)
    freeze(output / "sample_manifest.json", manifest)
    return {"inputs": inputs, "gold": gold, "manifest": manifest}
