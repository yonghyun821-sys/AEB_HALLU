from __future__ import annotations

import csv
import hashlib
import json
import os
import random
from contextlib import contextmanager
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field

from taxonomy_experiment.config import load_config
from taxonomy_experiment.io import append_jsonl, iter_jsonl, read_json, write_json, write_jsonl
from taxonomy_experiment.llm import BudgetExceededError, CachedLLM, TruncatedResponseError
from taxonomy_experiment.token_count import TokenCounter

from .data import CONDITIONS, DATASETS, digest, freeze, prepare
from .metrics import score_predictions, summarize

HERE = Path(__file__).resolve().parent


class StepOutput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    mechanism: str = Field(min_length=1, max_length=240)
    predicted_step_id: str = Field(min_length=1, max_length=40)
    evidence: str = Field(min_length=1, max_length=240)


class SourceRef(BaseModel):
    model_config = ConfigDict(extra="forbid")
    taxonomy_id: str
    category_id: str


class MergedCategory(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(min_length=1)
    definition: str = Field(min_length=1)
    sources: list[SourceRef] = Field(min_length=1)


class MergeOutput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    categories: list[MergedCategory] = Field(min_length=1, max_length=27)


def source_taxonomies(root: Path) -> dict:
    return {"agentrx": read_json(root / "taxonomies/agentrx_taxonomy.json"),
            "agenterrorbench": read_json(root / "taxonomies/agenterror_taxonomy.json")}


def guidance(dataset: str, condition: str, taxonomies: dict) -> list[dict]:
    if dataset not in DATASETS or condition not in CONDITIONS:
        raise ValueError("Unknown dataset or condition")
    if condition == "no_label":
        return []
    other = DATASETS[1] if dataset == DATASETS[0] else DATASETS[0]
    selected = taxonomies[{"own": dataset, "foreign": other, "merged": "merged"}[condition]]
    return [{"name": c["name"], "definition": c["definition"]} for c in selected["categories"]]


def build_prompt(record: dict, condition: str, taxonomies: dict) -> dict:
    # Explicit projection prevents a caller's extra annotation fields entering prompts.
    visible = {"task": record["task"], "context": record["context"],
               "candidate_step_ids": record["candidate_step_ids"], "steps": record["steps"]}
    if "shared_text" in record:
        visible["shared_text"] = record["shared_text"]
    body = json.dumps(visible,
                      ensure_ascii=False, separators=(",", ":"))
    block = json.dumps(guidance(record["dataset"], condition, taxonomies), ensure_ascii=False)
    return {"system_prompt": (HERE / "prompts/step_system.txt").read_text(encoding="utf-8"),
            "user_prompt": "DIAGNOSTIC_DEFINITIONS_JSON\n" + block + "\nVISIBLE_EXECUTION_JSON\n" + body,
            "base_user_prompt": body}


def validate_merge(merged: dict, sources: dict) -> None:
    parsed = MergeOutput.model_validate(merged)
    expected = {(t["taxonomy_id"], str(c["id"])) for t in sources.values() for c in t["categories"]}
    refs = [(s.taxonomy_id, s.category_id) for c in parsed.categories for s in c.sources]
    names = [c.name.strip().casefold() for c in parsed.categories]
    if set(refs) != expected or len(refs) != len(expected) or len(names) != len(set(names)):
        raise ValueError("Merge must cover all source categories exactly once, with unique names")


def call(llm: CachedLLM, model: dict, system: str, user: str, schema: type[BaseModel], seed: int):
    return llm.call(model=model["name"], system_prompt=system, user_prompt=user,
                    temperature=model.get("temperature"), reasoning_effort=model.get("reasoning_effort"),
                    seed=seed, provider=model.get("provider"), max_output_tokens=int(model["max_output_tokens"]),
                    response_model=schema)


def obtain_merge(config: dict, sources: dict, output: Path, llm: CachedLLM) -> dict:
    path = output / "merged_taxonomy.json"
    if path.exists():
        return read_frozen_merge(output, sources)
    if config.get("merge_policy", {}).get("strategy") == "reuse_frozen":
        merged, audit = reused_merge(config, sources)
        freeze(output / "merge_audit.json", audit)
        freeze(path, merged)
        return merged
    user = json.dumps([{ "taxonomy_id": t["taxonomy_id"],
                         "categories": [{k: c[k] for k in ("id", "name", "definition")}
                                        for c in t["categories"]]} for t in sources.values()],
                      ensure_ascii=False)
    system = (HERE / "prompts/merge_system.txt").read_text(encoding="utf-8")
    parsed, meta = call(llm, config["models"]["merge"], system, user, MergeOutput,
                        int(config["experiment"]["seed"]))
    merged = parsed.model_dump()
    # Structural failures stop the experiment; no performance-based merge search.
    validate_merge(merged, sources)
    freeze(output / "merge_audit.json", {"source_hashes": {k: digest(v) for k, v in sources.items()},
                                        "merged_sha256": digest(merged),
                                        "coverage_exactly_once": True,
                                        "call": {"cache_key": meta["cache_key"],
                                                 "response_metadata": meta.get("response_metadata", {})}})
    freeze(path, merged)
    return merged


def reused_merge(config: dict, sources: dict) -> tuple[dict, dict]:
    source = read_json(config["_root"] / config["merge_policy"]["source"])
    original_hashes = {t["taxonomy_id"]: hashlib.sha256(json.dumps(t, ensure_ascii=False,
                       sort_keys=True, separators=(",", ":")).encode()).hexdigest() for t in sources.values()}
    if source.get("generated_by", {}).get("source_taxonomy_hashes") != original_hashes:
        raise ValueError("Existing merge uses different source taxonomies")
    merged = {"categories": [{"name": c["name"], "definition": c["definition"],
                              "sources": [{"taxonomy_id": ref["source_taxonomy_id"],
                                           "category_id": str(ref["source_category_id"])}
                                          for ref in c["source_categories"]]}
                             for c in source["categories"]]}
    validate_merge(merged, sources)
    return merged, {"policy": "reuse_frozen_metadata_merge_no_api", "merged_sha256": digest(merged),
                    "source_merge_sha256": digest(source), "original_source": config["merge_policy"]["source"],
                    "source_hashes": {k: digest(v) for k, v in sources.items()}, "coverage_exactly_once": True,
                    "new_merge_api_calls": 0}


def read_frozen_merge(output: Path, sources: dict) -> dict:
    merged, audit = read_json(output / "merged_taxonomy.json"), read_json(output / "merge_audit.json")
    validate_merge(merged, sources)
    if audit["merged_sha256"] != digest(merged) or audit["source_hashes"] != {k: digest(v) for k, v in sources.items()}:
        raise ValueError("Frozen merge or its source taxonomy changed")
    return merged


def preflight(config: dict, prepared: dict, sources: dict, output: Path) -> dict:
    model = config["models"]["step"]
    counter = TokenCounter.for_model(model["name"], model["tokenizer_encoding"])
    reuse = config.get("merge_policy", {}).get("strategy") == "reuse_frozen"
    # A reused artifact is known exactly; fresh-generation mode needs a proxy.
    proxy = reused_merge(config, sources)[0] if reuse else {"categories": [c for t in sources.values() for c in t["categories"]]}
    taxonomies = {**sources, "merged": proxy}
    tokens, checks = [], {"condition_invariance": True, "no_label_empty": True,
                          "gold_separate": True, "candidates_match_visible_steps": True}
    for record in prepared["inputs"]:
        bases, systems = set(), set()
        checks["gold_separate"] &= not any(k.startswith("gold") for k in record)
        checks["candidates_match_visible_steps"] &= record["candidate_step_ids"] == [s["step_id"] for s in record["steps"]]
        for condition in CONDITIONS:
            p = build_prompt(record, condition, taxonomies)
            tokens.append(counter.count(p["system_prompt"] + "\n" + p["user_prompt"]))
            bases.add(p["base_user_prompt"])
            systems.add(p["system_prompt"])
        checks["condition_invariance"] &= len(bases) == len(systems) == 1
        checks["no_label_empty"] &= guidance(record["dataset"], "no_label", taxonomies) == []
    if not tokens:
        raise ValueError("Empty experiment")
    checks["context_window"] = max(tokens) * float(config["cost_budget"]["input_token_safety_multiplier"]) + model["max_output_tokens"] < model["context_window"]
    prices = model["pricing_usd_per_million"]
    estimate = (sum(tokens) * float(config["cost_budget"]["input_token_safety_multiplier"]) * prices["input"]
                + len(tokens) * model["max_output_tokens"] * prices["output"]) / 1_000_000
    merge_model = config["models"]["merge"]
    merge_reserve = (20000 * merge_model["pricing_usd_per_million"]["input"]
                     + merge_model["max_output_tokens"] * merge_model["pricing_usd_per_million"]["output"]) / 1_000_000
    if reuse:
        merge_reserve = 0.0
    attempts = int(config["api"]["max_retries"])
    retry_reserve = estimate * attempts + merge_reserve * attempts
    ledger_path = Path(config["cost_budget"].get("ledger_path", output / "api_ledger.jsonl"))
    if not ledger_path.is_absolute():
        ledger_path = config["_root"] / ledger_path
    spent = sum(float(r.get("cost_usd", 0)) for r in iter_jsonl(ledger_path)) if ledger_path.exists() else 0.0
    checks["configured_budget"] = spent + retry_reserve <= float(config["cost_budget"]["max_inference_usd"])
    report = {"status": "READY" if all(checks.values()) else "STOP", "checks": checks,
              "api_calls": 0, "trajectories": len(prepared["inputs"]), "predictions": len(tokens),
              "tokenizer_proxy": counter.encoding_name,
              "max_prompt_tokens_proxy": max(tokens), "step_input_tokens_proxy": sum(tokens),
              "estimated_reserve_usd": estimate + merge_reserve,
              "estimated_reserve_all_attempts_usd": retry_reserve,
              "shared_ledger_spend_usd": spent,
              "merge_policy": "reuse_frozen_no_call" if reuse else "fresh_generation",
              "hard_cap_usd": config["cost_budget"]["max_inference_usd"],
              "estimate_policy": "configured price ceilings; token safety multiplier; all allowed attempts also reserved; runtime cap enforced per call"}
    write_json(output / "preflight.json", report)
    if report["status"] != "READY":
        raise RuntimeError(f"Offline preflight failed: {report}")
    return report


@contextmanager
def run_lock(path: Path):
    """OS lock is released on process exit, including crashes."""
    with path.open("a+b") as handle:
        if path.stat().st_size == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle, fcntl.LOCK_UN)


def planned_requests(inputs: list[dict], seed: int) -> list[tuple[dict, str, int]]:
    requests = []
    for record in sorted(inputs, key=lambda r: digest([seed, r["dataset"], r["trajectory_id"]])):
        per_record = int(digest([seed, record["dataset"], record["trajectory_id"]])[:8], 16) % 2_147_483_647
        conditions = list(CONDITIONS)
        random.Random(per_record).shuffle(conditions)
        requests.extend((record, condition, per_record) for condition in conditions)
    return requests


def predict(config: dict, inputs: list[dict], taxonomies: dict, output: Path,
            llm: CachedLLM, *, smoke_only: bool) -> dict:
    path = output / "predictions.jsonl"
    completed = {}
    for row in iter_jsonl(path) if path.exists() else []:
        key = (row["dataset"], row["trajectory_id"], row["condition"])
        if key in completed:
            raise ValueError(f"Duplicate stored prediction: {key}")
        completed[key] = row
    planned = planned_requests(inputs, int(config["experiment"]["seed"]))
    allowed = {(r["dataset"], r["trajectory_id"], c) for r, c, _ in planned}
    if completed.keys() - allowed:
        raise ValueError("Stored predictions include unplanned records")
    if smoke_only:
        selected = {d: [] for d in DATASETS}
        for record, _, _ in planned:
            if record["trajectory_id"] not in selected[record["dataset"]] and len(selected[record["dataset"]]) < 2:
                selected[record["dataset"]].append(record["trajectory_id"])
        planned = [p for p in planned if p[0]["trajectory_id"] in selected[p[0]["dataset"]]]
    model = config["models"]["step"]
    counter = TokenCounter.for_model(model["name"], model["tokenizer_encoding"])
    for record, condition, seed in planned:
        key = (record["dataset"], record["trajectory_id"], condition)
        prompt = build_prompt(record, condition, taxonomies)
        prompt_hash = digest([prompt["system_prompt"], prompt["user_prompt"]])
        if key in completed:
            if completed[key]["prompt_sha256"] != prompt_hash or completed[key]["seed"] != seed:
                raise ValueError("Stored prediction prompt or seed differs")
            continue
        count = counter.count(prompt["system_prompt"] + prompt["user_prompt"])
        if count * float(config["cost_budget"]["input_token_safety_multiplier"]) + model["max_output_tokens"] >= model["context_window"]:
            raise RuntimeError("Actual merged prompt exceeds context; stop without changing sample")
        row = {"dataset": key[0], "trajectory_id": key[1], "condition": condition,
               "seed": seed, "prompt_sha256": prompt_hash}
        try:
            parsed, metadata = call(llm, model, prompt["system_prompt"], prompt["user_prompt"], StepOutput, seed)
            row.update(parsed.model_dump())
            row.update(status="ok" if parsed.predicted_step_id in record["candidate_step_ids"] else "invalid_step",
                       call=metadata)
        except BudgetExceededError:
            raise  # Budget stops are incomplete work, never a full set of errors.
        except (RuntimeError, TruncatedResponseError) as exc:
            row.update(status="call_failed", predicted_step_id=None, error=str(exc))
        append_jsonl(path, row)
        completed[key] = row
        print(f"[step-v2] {len(completed)}/{len(inputs) * 4} {condition}: {row['status']}", flush=True)
    return {"status": "SMOKE_COMPLETE" if smoke_only else "PREDICTIONS_COMPLETE",
            "stored_predictions": len(completed)}


def csv_file(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def analyze(config: dict, prepared: dict, output: Path) -> dict:
    scored = score_predictions(prepared["inputs"], prepared["gold"],
                               list(iter_jsonl(output / "predictions.jsonl")))
    report = summarize(scored, resamples=int(config["analysis"]["resamples"]),
                       seed=int(config["analysis"]["seed"]))
    write_json(output / "results.json", report)
    write_jsonl(output / "scored_predictions.jsonl", scored)
    ledger_path = Path(config.get("cost_budget", {}).get("ledger_path", output / "api_ledger.jsonl"))
    if not ledger_path.is_absolute():
        ledger_path = config["_root"] / ledger_path
    ledger = list(iter_jsonl(ledger_path)) if ledger_path.exists() else []
    write_json(output / "cost_summary.json", {"recorded_api_responses": len(ledger),
               "recorded_cost_usd": sum(float(row.get("cost_usd", 0)) for row in ledger),
               "configured_cap_usd": config.get("cost_budget", {}).get("max_inference_usd"),
               "note": "Configured ledger includes billed retries and all runs sharing the pilot's cumulative cap.",
               "ledger_path": str(ledger_path)})
    for name, rows in report.items():
        csv_file(output / f"{name}.csv", rows)
    lines = ["# Step accuracy v2", "", "Primary: nontrivial trajectories; equal task weight within each dataset; equal dataset weight in macro.",
             "Failed/invalid responses count as incorrect. Complete four-condition pairs are required.", "",
             "| Dataset | Condition | Task-balanced exact | 95% task bootstrap CI |",
             "|---|---|---:|---:|"]
    for row in report["primary"]:
        lines.append(f"| {row['dataset']} | {row['condition']} | {row['task_balanced_exact_accuracy']:.2%} | "
                     f"{row['ci_low']:.2%}–{row['ci_high']:.2%} |")
    lines += ["", "See diagnostics.csv for ordinary row exact accuracy, single-candidate, gold-last/non-last, ±1, invalid counts and positional baselines.",
              "Contrasts use the same estimator as primary scores. Holm adjustment covers all 15 contrasts.",
              "Task sign-flip p-values assume exchangeability under the paired null; intervals describe task sampling, not model/annotation uncertainty.",
              "This is an exploratory redesign on previously used data, not an untouched confirmatory test.", ""]
    if config.get("experiment", {}).get("pilot_per_dataset"):
        lines += ["Budget pilot: small, domain-balanced sample of unique tasks under a fixed input-length limit.",
                  "Selection favors shorter inputs; scores are not full-dataset estimates. Shared-text references may affect model performance.", ""]
    (output / "RESULTS.md").write_text("\n".join(lines), encoding="utf-8")
    return {"status": "COMPLETE", "results": str(output / "RESULTS.md")}


def workflow(config_path: str | Path, mode: str) -> dict:
    config = load_config(config_path)
    root = config["_root"]
    base = root / config["output_dir"]
    base.mkdir(parents=True, exist_ok=True)
    sources = source_taxonomies(root)
    exp = config["experiment"]
    prepared = prepare(root, base / "prepared", visible_token_limit=int(exp["visible_token_limit"]),
                       compact_shared_lines=bool(exp.get("compact_shared_lines", False)),
                       pilot_per_dataset=exp.get("pilot_per_dataset"), seed=int(exp["seed"]))
    identity = {"config": {k: v for k, v in config.items() if not k.startswith("_")},
                "sample": prepared["manifest"], "sources": sources,
                "code": {p.name: p.read_text(encoding="utf-8") for p in sorted(HERE.glob("*.py"))},
                "protocol": (HERE / "PROTOCOL.md").read_text(encoding="utf-8"),
                "prompts": {p.name: p.read_text(encoding="utf-8") for p in sorted((HERE / "prompts").glob("*.txt"))},
                "shared_code": {p: (root / "src/taxonomy_experiment" / p).read_text(encoding="utf-8")
                                for p in ("llm.py", "token_count.py", "datasets/agentrx.py", "datasets/agenterrorbench.py")}}
    if config.get("merge_policy", {}).get("strategy") == "reuse_frozen":
        identity["reused_merge"] = read_json(root / config["merge_policy"]["source"])
    output = base / ("run-" + digest(identity)[:16])
    output.mkdir(exist_ok=True)
    freeze(output / "identity.json", identity)
    for name, taxonomy in sources.items():
        freeze(output / f"{name}_taxonomy.json", taxonomy)
    audit = preflight(config, prepared, sources, output)
    if mode == "preflight":
        return {**audit, "run_directory": str(output)}
    # All identities sharing a budget must serialize ledger checks and billing.
    budget_ledger = Path(config["cost_budget"].get("ledger_path", output / "api_ledger.jsonl"))
    if not budget_ledger.is_absolute():
        budget_ledger = root / budget_ledger
    budget_ledger.parent.mkdir(parents=True, exist_ok=True)
    with run_lock(budget_ledger.with_suffix(".lock")):
        if mode == "analyze":
            read_frozen_merge(output, sources)
            return {**analyze(config, prepared, output), "run_directory": str(output)}
        live_config = {**config, "cost_budget": {**config["cost_budget"],
                       "ledger_path": config["cost_budget"].get("ledger_path", str(output / "api_ledger.jsonl"))}}
        llm = CachedLLM(live_config, output / "cache")
        merged = obtain_merge(config, sources, output, llm)
        result = predict(config, prepared["inputs"], {**sources, "merged": merged}, output,
                         llm, smoke_only=mode == "smoke")
        if mode == "run":
            result = analyze(config, prepared, output)
        return {**result, "run_directory": str(output)}
