"""Offline data audit and deterministic group split. No model/API dependencies."""
from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from pathlib import Path

import tiktoken

HERE = Path(__file__).resolve().parent
DATA = HERE / 'data'
ROOT = HERE.parents[1]
SEED = 'taxonomy-attribution-20261031-v1'
MAX_TRACE_PROXY_TOKENS = 100000


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def sha(obj):
    return hashlib.sha256(canonical(obj).encode('utf-8')).hexdigest()


def has_image(value):
    if isinstance(value, dict):
        if value.get('type') in ('image', 'image_url', 'input_image'):
            return True
        return any(has_image(v) for v in value.values())
    return isinstance(value, list) and any(has_image(v) for v in value)


def project(metadata, records):
    """Whitelist visible fields. Author labels, answers, reasons never enter this object."""
    steps = []
    for s in records:
        choices = s['output']['choices']
        steps.append({
            'step_id': s['step_id'], 'agent_id': s['agent_id'], 'agent_name': s['agent_name'],
            'input': s['input'],
            'output_messages': [c['message'] for c in choices],
            'tool_logs': s['tool_logs'],
        })
    return {k: metadata[k] for k in (
        'task_instruction', 'system_name', 'agent_system_intro', 'agent_configuration'
    )} | {'steps': steps}


def pack(visible):
    """Deduplicate complete message objects, preserving their exact ordered occurrences."""
    pool = {}
    def ref(message):
        key = 'M' + sha(message)[:20]
        if key in pool and pool[key] != message:
            raise ValueError('Message ID collision')
        pool[key] = message
        return key
    result = {k: v for k, v in visible.items() if k != 'steps'}
    steps = []
    for original in visible['steps']:
        s = dict(original)
        s['input'] = dict(s['input'])
        s['input']['messages'] = [ref(m) for m in s['input']['messages']]
        s['output_messages'] = [ref(m) for m in s['output_messages']]
        steps.append(s)
    return result | {'message_dictionary': pool, 'steps': steps}


def unpack(packed):
    pool = packed['message_dictionary']
    result = {k: v for k, v in packed.items() if k not in ('message_dictionary', 'steps')}
    steps = []
    for original in packed['steps']:
        s = dict(original)
        s['input'] = dict(s['input'])
        s['input']['messages'] = [pool[k] for k in s['input']['messages']]
        s['output_messages'] = [pool[k] for k in s['output_messages']]
        steps.append(s)
    return result | {'steps': steps}


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def prepare():
    enc = tiktoken.get_encoding('o200k_base')
    source = json.loads((DATA/'source_members_manifest.json').read_text(encoding='utf-8'))
    source_hashes = {m['path']: m['sha256'] for m in source['members']}
    old_path = ROOT/'data/processed/agentrx_inputs.jsonl'
    if not old_path.exists():
        raise RuntimeError('Known prior AgentRx cohort is required for the overlap audit')
    normalize = lambda text: re.sub(r'\s+', ' ', text).strip().casefold()
    old_questions = {normalize(json.loads(line)['instruction'])
                     for line in old_path.read_text(encoding='utf-8').splitlines() if line.strip()}
    rows = []
    for path in sorted((DATA/'raw').rglob('trace_metadata.json')):
        metadata = json.loads(path.read_text(encoding='utf-8'))
        step_path = path.with_name('step_records.json')
        records = json.loads(step_path.read_text(encoding='utf-8'))
        for member in (path, step_path):
            key = member.relative_to(DATA/'raw').as_posix()
            if hashlib.sha256(member.read_bytes()).hexdigest() != source_hashes[key]:
                raise ValueError('Pinned source member changed: '+key)
        visible = project(metadata, records)
        packed = pack(visible)
        if unpack(packed) != visible:
            raise ValueError('Message compression is not lossless')
        tokens = len(enc.encode(canonical(packed), disallowed_special=()))
        counts = Counter(s['agent_name'] for s in records)
        reasons = []
        if has_image(visible): reasons.append('image_input_not_supported_by_text_model')
        if len(records) < 5: reasons.append('fewer_than_five_visible_events')
        if sum(v >= 2 for v in counts.values()) < 2:
            reasons.append('fewer_than_two_repeated_actors')
        if tokens > MAX_TRACE_PROXY_TOKENS: reasons.append('over_100000_proxy_tokens_without_truncation')
        gold_agent, gold_step = metadata['mistake_agent'], metadata['mistake_step']
        matches = [s for s in records if s['agent_name'] == gold_agent and str(s['step_id']) == gold_step]
        if len(matches) != 1: reasons.append('unresolvable_native_gold_pair')
        ids = [s['step_id'] for s in records]
        if len(set(ids)) != len(ids): reasons.append('duplicate_step_id')
        normalized = normalize(metadata['task_instruction'])
        group = hashlib.sha256(normalized.encode('utf-8')).hexdigest()
        case = sha(path.parent.relative_to(DATA/'raw').as_posix())[:20]
        rows.append({'case_id': case, 'source_directory': path.parent.relative_to(DATA/'raw').as_posix(),
                     'source_task_id': metadata['task_id'], 'group_id': group,
                     'system': path.parent.parent.name, 'events': len(records),
                     'actors': len(counts), 'trace_proxy_tokens': tokens,
                     'known_prior_agentrx_task_overlap': normalized in old_questions,
                     'eligible': not reasons, 'exclusion_reasons': reasons})
        write(DATA/'prepared/traces'/f'{case}.json', packed)
        write(DATA/'prepared/gold'/f'{case}.json', {'case_id': case, 'who': gold_agent,
              'when': gold_step, 'resolvable': len(matches) == 1})
    eligible = [r for r in rows if r['eligible']]
    # Same task ID AND normalized same instruction are connected before splitting.
    parent = {r['group_id']: r['group_id'] for r in rows}
    def find(g):
        while parent[g] != g:
            parent[g] = parent[parent[g]]; g = parent[g]
        return g
    task_groups = {}
    for r in rows:
        task = r['source_task_id']; g = r['group_id']
        if task in task_groups: parent[find(g)] = find(task_groups[task])
        else: task_groups[task] = g
    for r in rows: r['group_id'] = find(r['group_id'])
    groups = sorted({r['group_id'] for r in eligible}, key=lambda g: sha(SEED+g))
    # Known prior tasks are development-only; fill to one quarter with hash-ordered groups.
    dev = {r['group_id'] for r in eligible if r['known_prior_agentrx_task_overlap']}
    for g in groups:
        if len(dev) >= max(1, len(groups)//4): break
        dev.add(g)
    # Stability development must cover every eligible system/task-source stratum.
    for system in sorted({r['system'] for r in eligible}):
        for g in groups:
            if sum(r['system'] == system and r['group_id'] in dev for r in eligible) >= 2: break
            if any(r['system'] == system and r['group_id'] == g for r in eligible): dev.add(g)
    split = {'seed': SEED, 'rule': 'known prior AgentRx tasks development-only; hash-fill to floor(G/4) groups; add groups until each system/source stratum has >=2 development cases',
             'development': [r['case_id'] for r in eligible if r['group_id'] in dev],
             'evaluation': [r['case_id'] for r in eligible if r['group_id'] not in dev]}
    for r in rows:
        r['split'] = ('development' if r['group_id'] in dev else 'evaluation') if r['eligible'] else 'excluded'
    summary = {'source_revision': source['revision'], 'source_traces_audited': len(rows),
               'eligible': len(eligible), 'excluded': len(rows)-len(eligible),
               'independent_eligible_task_groups': len(groups),
               'exclusion_counts_overlapping': dict(Counter(reason for r in rows for reason in r['exclusion_reasons'])),
               'eligible_by_system': dict(Counter(r['system'] for r in eligible)),
               'split_by_system': {s: dict(Counter(r['system'] for r in rows if r['split'] == s))
                                   for s in ('development','evaluation')},
               'split_cases': {s: sum(r['split'] == s for r in rows) for s in ('development','evaluation')},
               'split_groups': {'development': len(dev), 'evaluation': len(groups)-len(dev)},
               'proxy_tokenizer': 'o200k_base; NOT the exact DeepSeek tokenizer',
               'known_prior_overlap_cases_development_only': sum(r['known_prior_agentrx_task_overlap'] for r in eligible),
               'prior_overlap_audit_scope': 'exact whitespace/case-normalized tasks in data/processed/agentrx_inputs.jsonl only; not a global contamination audit',
               'prior_cohort_file_sha256': hashlib.sha256(old_path.read_bytes()).hexdigest(),
               'max_trace_proxy_tokens': MAX_TRACE_PROXY_TOKENS,
               'paid_model_calls': 0, 'roundtrip_checked_all_traces': True,
               'evaluation_status': 'design_split_only_not_claimed_preregistered_or_contamination_free',
               'cohort_sha256': sha(rows), 'split_sha256': sha(split)}
    for s in ('development', 'evaluation'):
        vals = sorted(r['trace_proxy_tokens'] for r in rows if r['split'] == s)
        summary[s+'_trace_tokens'] = {'sum': sum(vals), 'min': min(vals),
                                      'median': vals[len(vals)//2], 'max': max(vals)}
    write(DATA/'prepared/cohort.json', rows)
    write(DATA/'prepared/split.json', split)
    write(DATA/'prepared/audit.json', summary)
    print(json.dumps(summary, indent=2))
    return summary


if __name__ == '__main__':
    prepare()
