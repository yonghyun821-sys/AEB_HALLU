"""Frozen two-stage study, with development gates before held-out evaluation."""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
import random
import shutil
import threading
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from pathlib import Path

from taxonomy_experiment.config import _load_project_dotenv
from taxonomy_experiment.io import append_jsonl, read_json, write_json
from experiments.step_accuracy_v2.core import run_lock
from .prepare import HERE, DATA, ROOT, sha, pack, project
from .prompting import proposal_messages, verification_messages, freeze_candidates, parse_verdict
from .runtime import Client, Ledger, Progress, QualityGate, StopRun, load_rows

ARTIFACTS = HERE/'artifacts'
ARMS = ('generic','source_agentrx','union','merged')


def freeze_files(identity,output):
    for relative,expected in identity['files_sha256'].items():
        path=output/'frozen'/relative
        if not path.exists():
            path.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(ROOT/relative,path)
        if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
            raise StopRun('Frozen experiment file differs from recorded identity: '+relative)


def snapshot():
    config = read_json(HERE/'design_config.json')
    cohort = read_json(DATA/'prepared/cohort.json'); split = read_json(DATA/'prepared/split.json')
    if sha(cohort) != config['cohort_sha256']: raise StopRun('Cohort differs from the reviewed design')
    if config['conditions'] != list(ARMS): raise StopRun('Unexpected condition set')
    if not 0 < config['budget']['hard_cap_usd'] <= 8: raise StopRun('This study is authorized for at most $8')
    if config['model']['provider']['only'] != ['deepinfra/fp8'] or config['model']['provider']['allow_fallbacks']:
        raise StopRun('Provider route differs from the implemented pinned route')
    selected = [r for r in cohort if r['eligible']]
    planned = split['development']+split['evaluation']
    if len(planned) != len(set(planned)) or set(planned) != {r['case_id'] for r in selected}:
        raise StopRun('Case IDs in split do not match eligible cohort')
    by_id = {r['case_id']:r for r in selected}
    groups = [{by_id[k]['group_id'] for k in split[s]} for s in ('development','evaluation')]
    if groups[0] & groups[1]: raise StopRun('Task group leakage between splits')
    if any(by_id[k]['known_prior_agentrx_task_overlap'] for k in split['evaluation']):
        raise StopRun('Known prior task appeared in held-out evaluation')
    files = [p for p in HERE.glob('*.py') if not p.name.startswith('test_')]
    files += [HERE/'design_config.json',DATA/'prepared/cohort.json',DATA/'prepared/split.json']
    files += [p for p in (HERE/'sources').iterdir() if p.is_file()]
    files += [ROOT/'experiments/deepseek_step_relation_merge/streaming.py',
              ROOT/'experiments/step_accuracy_v2/core.py', ROOT/'src/taxonomy_experiment/io.py',
              ROOT/'src/taxonomy_experiment/config.py']
    for k in planned:
        for kind in ('traces','gold'): files.append(DATA/'prepared'/kind/(k+'.json'))
    hashes = {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
    # Check structural coordinates before any paid request; no label-based candidate selection.
    source = read_json(DATA/'source_members_manifest.json')
    member_hashes = {r['path']:r['sha256'] for r in source['members']}
    for row in selected:
        trace = read_json(DATA/'prepared/traces'/(row['case_id']+'.json'))
        source_dir = DATA/'raw'/row['source_directory']
        for name in ('trace_metadata.json','step_records.json'):
            member = source_dir/name
            if hashlib.sha256(member.read_bytes()).hexdigest() != member_hashes[member.relative_to(DATA/'raw').as_posix()]:
                raise StopRun('Pinned public source JSON changed')
        metadata = read_json(source_dir/'trace_metadata.json'); records = read_json(source_dir/'step_records.json')
        if trace != pack(project(metadata,records)): raise StopRun('Prepared trace differs from the source-only whitelist projection')
        gold = read_json(DATA/'prepared/gold'/(row['case_id']+'.json'))
        if gold['who'] != metadata['mistake_agent'] or gold['when'] != metadata['mistake_step']:
            raise StopRun('Prepared scoring coordinates differ from native annotation')
        ids = [s['step_id'] for s in trace['steps']]
        if len(ids) != len(set(ids)) or any(type(k) is not int for k in ids):
            raise StopRun('Invalid visible native step coordinates')
    packages = {name:importlib.metadata.version(name) for name in ('openai','httpx','pydantic','tiktoken')}
    identity = {'version':'contrastive-attribution-runtime-v1','config':config,'files_sha256':hashes,
                'packages':packages,'phase_counts':{s:len(split[s]) for s in ('development','evaluation')}}
    return config,cohort,split,identity


def preflight():
    _load_project_dotenv(ROOT)
    config,cohort,split,identity = snapshot()
    active = ARTIFACTS/'active_run.json'
    if active.exists() and read_json(active)['identity_sha256'] != sha(identity):
        raise StopRun('Active run is frozen to different code/data/config; refusing a new paid run or budget reset')
    return {'status':'OFFLINE_READY','paid_calls':0,'api_key_configured':bool(os.environ.get('OPENROUTER_API_KEY')),
            'development_cases':len(split['development']),'evaluation_cases':len(split['evaluation']),
            'maximum_model_calls':len([r for r in cohort if r['eligible']])*5,
            'budget_cap_usd':config['budget']['hard_cap_usd'],'endpoint':'deepinfra/fp8',
            'workers':2,'identity_sha256':sha(identity),'live_endpoint_validated':False}


def extract(raw):
    choices = raw.get('choices') or []
    if len(choices) != 1 or choices[0].get('finish_reason') != 'stop':
        raise ValueError('Missing stop finish reason or output token limit reached')
    text = (choices[0].get('message') or {}).get('content')
    if not isinstance(text,str) or not text.strip(): raise ValueError('Empty model output')
    value = json.loads(text)
    if not isinstance(value,dict): raise ValueError('JSON output must be an object')
    return value


class Study:
    def __init__(self,config,cohort,split,output,client,progress):
        self.config,self.cohort,self.split,self.output = config,cohort,split,output
        self.client,self.progress = client,progress
        frozen=output/'frozen/experiments/taxonomy_contrastive_attribution'
        self.data=frozen/'data' if frozen.exists() else DATA
        source=frozen/'sources' if frozen.exists() else HERE/'sources'
        self.proposals = {r['case_id']:r for r in load_rows(output/'proposals.jsonl')}
        pred = load_rows(output/'predictions.jsonl')
        self.predictions = {(r['case_id'],r['arm']):r for r in pred}
        self.events = load_rows(output/'call_events.jsonl')
        if len(self.proposals) != len(load_rows(output/'proposals.jsonl')) or len(self.predictions) != len(pred):
            raise StopRun('Duplicate result rows detected')
        self.gate = QualityGate(config['continuous_gate']); self.cancel = threading.Event()
        self.guidance = {a:(source/(a+'.txt')).read_text(encoding='utf-8').removesuffix('\n') for a in ARMS}
        self.event_keys = {r['operation'] for r in self.events}
        if len(self.event_keys) != len(self.events): raise StopRun('Duplicate call events')
        # Results saved immediately before a crash may lack their derived quality event.
        recovered = sorted([r for r in list(self.proposals.values())+pred if r.get('cache_key')],
                           key=lambda r:r['operation'])
        for row in recovered: self.record_event(row)
        self.refresh()
        self.gate.check(self.events)

    def refresh(self):
        skipped = 4*sum(not r['valid'] for r in self.proposals.values())
        self.progress.update(calls_done=len(self.events),proposal_done=len(self.proposals),
            arms={a:sum(k[1]==a for k in self.predictions) for a in ARMS},
            invalid=sum(not r['valid'] for r in self.events),skipped=skipped)

    def record_event(self,row):
        if not row.get('cache_key') or row['operation'] in self.event_keys: return
        event = {k:row[k] for k in ('operation','arm','valid','cache_key','split')}
        append_jsonl(self.output/'call_events.jsonl',event)
        self.events.append(event); self.event_keys.add(row['operation'])

    def one(self,split,case,arm):
        operation = split+':'+case+':'+arm
        trace = read_json(self.data/'prepared/traces'/(case+'.json'))
        candidates = self.proposals[case].get('candidates') if arm != 'proposal' else None
        messages = proposal_messages(trace) if arm=='proposal' else verification_messages(trace,candidates,self.guidance[arm])
        worker = self.progress.worker(operation)
        try:
            raw,key = self.client.call(messages,worker,self.cancel)
            row = {'case_id':case,'split':split,'arm':arm,'operation':operation,'cache_key':key,'valid':False}
            try:
                value = extract(raw)
                if arm=='proposal': row['candidates'] = freeze_candidates(value,trace,case)
                else:
                    row['verdict'] = value; row.update(parse_verdict(value,trace,candidates))
                row['valid']=True
            except (ValueError,KeyError,TypeError,AttributeError) as exc:
                row['error'] = str(exc)[:400]
            return row
        finally: worker.close()

    def save(self,row):
        if row['arm']=='proposal':
            append_jsonl(self.output/'proposals.jsonl',row); self.proposals[row['case_id']] = row
        else:
            append_jsonl(self.output/'predictions.jsonl',row)
            self.predictions[(row['case_id'],row['arm'])] = row
        self.record_event(row); self.refresh()
        self.progress.emit('SAVED',message=row['operation']+(' valid' if row['valid'] else ' INVALID'))

    def stage(self,split,proposal):
        self.progress.emit('PHASE',phase=split+('_proposals' if proposal else '_verification'))
        planned=[]
        for case in sorted(self.split[split],key=lambda k:sha(['schedule-v1',split,k])):
            if proposal:
                if case not in self.proposals: planned.append((split,case,'proposal'))
            else:
                arms = list(ARMS); random.Random(sha(['arm-order-v1',case])).shuffle(arms)
                for arm in arms:
                    if (case,arm) in self.predictions: continue
                    if not self.proposals[case]['valid']:
                        self.save({'case_id':case,'split':split,'arm':arm,'operation':split+':'+case+':'+arm,
                                   'valid':False,'error':'Shared proposal failed; no verification request sent'})
                    else: planned.append((split,case,arm))
        iterator = iter(planned); stopped = None
        with ThreadPoolExecutor(max_workers=2) as pool:
            pending = {}
            def submit():
                task = next(iterator,None)
                if task is not None: pending[pool.submit(self.one,*task)] = task
            submit(); submit()
            while pending:
                done,_ = wait(pending,return_when=FIRST_COMPLETED)
                for future in sorted(done,key=lambda f:pending[f]):
                    pending.pop(future)
                    try:
                        row = future.result(); self.save(row); self.gate.check(self.events)
                    except BaseException as exc:
                        if stopped is None: stopped = exc
                        self.cancel.set()
                if stopped is None:
                    for _ in done: submit()
        if stopped is not None: raise stopped

    def development_gate(self,verification=False):
        cases = self.split['development']; n = len(cases); gates=self.config['development_gates']
        valid,who,when = 0,0,0
        for case in cases:
            row=self.proposals[case]
            if not row['valid']: continue
            valid+=1; gold=read_json(self.data/'prepared/gold'/(case+'.json'))
            who+=any(c['agent_name']==gold['who'] for c in row['candidates'])
            when+=any(str(c['step_id'])==gold['when'] for c in row['candidates'])
        report={'cases':n,'proposal_valid_fraction':valid/n,'who_candidate_coverage':who/n,
                'when_candidate_coverage':when/n,'status':'PASS'}
        tests=[valid/n>=gates['min_proposal_valid_fraction'],who/n>=gates['min_who_candidate_coverage'],
               when/n>=gates['min_when_candidate_coverage']]
        if verification:
            report['verifier_valid_fraction_per_condition']={a:sum(self.predictions[(k,a)]['valid'] for k in cases)/n for a in ARMS}
            tests.extend(v>=gates['min_verifier_valid_fraction_per_condition'] for v in report['verifier_valid_fraction_per_condition'].values())
        if not all(tests): report['status']='FAIL'
        write_json(self.output/('development_gate.json' if verification else 'candidate_gate.json'),report)
        if report['status']!='PASS': raise StopRun('Development gate failed; see gate JSON. Main evaluation has not started; review a new frozen protocol.')
        return report


def run(*, development_only=False):
    _load_project_dotenv(ROOT)
    config,cohort,split,identity = snapshot()
    if not os.environ.get('OPENROUTER_API_KEY'): raise StopRun('OPENROUTER_API_KEY is missing; set it in the project .env')
    ARTIFACTS.mkdir(exist_ok=True)
    with run_lock(ARTIFACTS/'budget.lock'):
        active=ARTIFACTS/'active_run.json'; key=sha(identity)
        output=ARTIFACTS/('run-'+key[:16]); output.mkdir(exist_ok=True)
        if active.exists():
            if read_json(active)['identity_sha256']!=key:
                raise StopRun('Code, data, dependencies or settings changed after freezing. Saved run cannot be silently replaced.')
        else:
            if (ARTIFACTS/'ledger.jsonl').exists(): raise StopRun('Ledger exists without active run identity; refusing a budget reset')
            write_json(output/'identity.json',identity)
            write_json(active,{'identity_sha256':key,'run_directory':str(output)})
        freeze_files(identity,output)
        ledger=Ledger(ARTIFACTS/'ledger.jsonl',config['budget']['hard_cap_usd'])
        client=Client(config,output,ledger); ledger.recover(client.cache)
        progress=Progress(output,ledger,len(split['development']+split['evaluation'])*5,
                          len(split['development']+split['evaluation']),len(split['development']+split['evaluation']))
        progress.start()
        try:
            study=Study(config,cohort,split,output,client,progress)
            progress.emit('START',message='Pinned DeepInfra FP8; reasoning=low; two workers; resume uses saved requests')
            study.stage('development',True); study.development_gate()
            study.stage('development',False); study.development_gate(True)
            if development_only:
                status='DEVELOPMENT_PASSED'; progress.emit(status,status=status,message='Resume without --development-only to evaluate')
            else:
                study.stage('evaluation',True); study.stage('evaluation',False)
                from .results import summarize
                summarize(cohort,split,study.proposals,study.predictions,output,ledger,data=study.data)
                status='COMPLETE'; progress.emit('COMPLETE',status=status,message=str(output/'RESULTS.md'))
            result={'status':status,'run_directory':str(output),'billing':{k:v for k,v in ledger.summary().items() if k!='holds'}}
            write_json(output/'status.json',result); return result
        except BaseException as exc:
            reason = str(exc) if isinstance(exc,StopRun) else ('Interrupted by user' if isinstance(exc,KeyboardInterrupt) else type(exc).__name__+'; inspect local logs')
            progress.emit('STOPPED',status='STOPPED',message=reason)
            write_json(output/'status.json',{'status':'STOPPED','reason':reason})
            raise StopRun(reason) from None
        finally: progress.close()
