"""Separate Who/When scores; paired problem-cluster bootstrap, no joint/What scores."""
from __future__ import annotations

import random
from collections import defaultdict

from taxonomy_experiment.io import read_json, write_json
from .prepare import DATA
from .runtime import StopRun


def summarize(cohort,split,proposals,predictions,output,ledger,*,data=None):
    data=DATA if data is None else data
    cases=split['evaluation']; arms=('generic','source_agentrx','union','merged'); n=len(cases)
    if not all((k,a) in predictions for k in cases for a in arms):
        raise StopRun('Evaluation incomplete; final scores will not be published')
    gold={k:read_json(data/'prepared/gold'/(k+'.json')) for k in cases}
    correct={}; summary={}
    for a in arms:
        values=[]
        for k in cases:
            r=predictions[(k,a)]
            hit=[int(r['valid'] and r.get('who')==gold[k]['who']),
                 int(r['valid'] and r.get('when')==gold[k]['when'])]
            correct[(k,a)]=hit; values.append(hit)
        summary[a]={'n':n,'who_correct':sum(v[0] for v in values),'when_correct':sum(v[1] for v in values),
                    'invalid':sum(not predictions[(k,a)]['valid'] for k in cases)}
    groups=defaultdict(list); lookup={r['case_id']:r for r in cohort}
    for k in cases: groups[lookup[k]['group_id']].append(k)
    groups=list(groups.values()); rng=random.Random(20261031); samples=[[],[]]
    for _ in range(5000):
        chosen=[k for g in rng.choices(groups,k=len(groups)) for k in g]
        for j in (0,1):
            samples[j].append(100*sum(correct[(k,'merged')][j]-correct[(k,'union')][j] for k in chosen)/len(chosen))
    effects={}
    for j,metric in enumerate(('who','when')):
        ordered=sorted(samples[j])
        effects[metric]={'merged_minus_union_pp':100*sum(correct[(k,'merged')][j]-correct[(k,'union')][j] for k in cases)/n,
                         'cluster_bootstrap_97_5_percent_interval_pp':[ordered[int(.0125*4999)],ordered[int(.9875*4999)]]}
    coverage={'who':sum(proposals[k]['valid'] and any(c['agent_name']==gold[k]['who'] for c in proposals[k]['candidates']) for k in cases)/n,
              'when':sum(proposals[k]['valid'] and any(str(c['step_id'])==gold[k]['when'] for c in proposals[k]['candidates']) for k in cases)/n}
    payload={'status':'COMPLETE','evaluation_cases':n,'evaluation_problem_groups':len(groups),'conditions':summary,
             'main_comparison':effects,'candidate_coverage':coverage,
             'billing':{k:v for k,v in ledger.summary().items() if k!='holds'}}
    write_json(output/'RESULTS.json',payload)
    lines=['# Taxonomy contrastive attribution results','','Status: COMPLETE.',
           f'Evaluation: {n} traces / {len(groups)} problem groups. Development excluded from reported accuracy.','',
           '| Condition | N | Who | When | Invalid including shared proposal failures |','|---|---:|---:|---:|---:|']
    for a,s in summary.items():
        lines.append(f'| {a} | {n} | {100*s["who_correct"]/n:.2f}% ({s["who_correct"]}/{n}) | {100*s["when_correct"]/n:.2f}% ({s["when_correct"]}/{n}) | {s["invalid"]} |')
    lines+=['','## Merged minus Union','','Intervals: paired problem-cluster bootstrap, 5,000 resamples; 97.5% per metric.','']
    for metric,e in effects.items():
        lo,hi=e['cluster_bootstrap_97_5_percent_interval_pp']
        lines.append(f'- {metric}: {e["merged_minus_union_pp"]:+.2f} pp; interval [{lo:+.2f}, {hi:+.2f}].')
    lines+=['',f'Candidate coverage: Who {coverage["who"]:.2%}; When {coverage["when"]:.2%}.',
            f'Total new-study billing, including development: ${payload["billing"]["billed"]:.4f}.','',
            'These are source-native attribution scores on a restricted text-only cohort. No repair, joint accuracy, or What accuracy was evaluated. Integrated guidance includes additional boundary information; a pure hierarchy-only effect is not identified.','']
    (output/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    return payload
