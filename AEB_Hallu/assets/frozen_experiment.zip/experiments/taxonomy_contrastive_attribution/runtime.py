"""Durable billing, streaming progress and continuous quality checks for this study."""
from __future__ import annotations

import asyncio
import math
import os
import threading
import time
import uuid
from collections import Counter
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from openai import APIStatusError
from taxonomy_experiment.io import append_jsonl, iter_jsonl, read_json, write_json
from experiments.deepseek_step_relation_merge.streaming import collect
from .prepare import sha


class StopRun(RuntimeError):
    pass


def load_rows(path):
    return list(iter_jsonl(path)) if path.exists() else []


class Ledger:
    def __init__(self, path, cap):
        if not math.isfinite(cap) or cap <= 0: raise StopRun('Invalid budget cap')
        self.path, self.cap = path, cap
        self.lock = threading.RLock()

    def summary(self):
        with self.lock:
            holds, billed, settled = {}, 0.0, set()
            for row in load_rows(self.path):
                cost = row.get('cost_usd')
                if type(cost) not in (int,float) or not math.isfinite(cost) or cost < 0:
                    raise StopRun('Invalid ledger cost; refusing to infer remaining budget')
                key = row['attempt_id']
                if row['kind'] == 'reserve':
                    if key in holds or key in settled: raise StopRun('Duplicate ledger reservation')
                    holds[key] = row
                elif row['kind'] in ('settle', 'reject'):
                    if key not in holds: raise StopRun('Unmatched ledger settlement')
                    holds.pop(key); settled.add(key)
                    if row['kind'] == 'settle': billed += row['cost_usd']
                else: raise StopRun('Unknown ledger entry')
            reserved = sum(r['cost_usd'] for r in holds.values())
            return {'billed': billed, 'reserved': reserved, 'guard': billed+reserved, 'holds': holds}

    def reserve(self, key, cost):
        with self.lock:
            if not math.isfinite(cost) or cost <= 0: raise StopRun('Invalid request reservation')
            s = self.summary()
            if any(r['cache_key'] == key for r in s['holds'].values()):
                raise StopRun('Unconfirmed billing for this request; automatic duplicate forbidden')
            if s['guard']+cost > self.cap:
                raise StopRun(f'Budget guard ${self.cap:g}: next reservation would exceed the cap')
            attempt = uuid.uuid4().hex
            append_jsonl(self.path, {'kind':'reserve','attempt_id':attempt,'cache_key':key,'cost_usd':cost})
            return attempt

    def finish(self, attempt, key, cost=None):
        with self.lock:
            if attempt not in self.summary()['holds']: return
            append_jsonl(self.path, {'kind':'reject' if cost is None else 'settle',
                'attempt_id':attempt,'cache_key':key,'cost_usd':0 if cost is None else cost})

    def recover(self, cache):
        for attempt, row in self.summary()['holds'].items():
            path = cache/(row['cache_key']+'.json')
            if not path.exists():
                raise StopRun('Unconfirmed previous request billing; stopped to prevent a duplicate. Inspect ledger.jsonl and provider usage.')
            raw = read_json(path)['raw_response']
            cost = (raw.get('usage') or {}).get('cost')
            if not isinstance(cost,(int,float)) or not math.isfinite(cost) or cost < 0:
                raise StopRun('Saved response has no authoritative cost; billing remains reserved')
            self.finish(attempt,row['cache_key'],cost)


class Progress:
    def __init__(self, output, ledger, total_calls, proposals, per_arm):
        self.output, self.ledger = output, ledger
        self.total, self.proposals, self.per_arm = total_calls, proposals, per_arm
        self.started = time.monotonic(); self.base_done = None
        self.lock = threading.RLock(); self.stop = threading.Event(); self.workers = {}
        self.fields = {'status':'STARTING','phase':'preflight','calls_done':0,'proposal_done':0,
                       'arms':{},'invalid':0,'skipped':0,'message':''}
        self.thread = threading.Thread(target=self._heartbeat,daemon=True)

    def start(self): self.thread.start()
    def close(self): self.stop.set(); self.thread.join(timeout=2)

    def _heartbeat(self):
        while not self.stop.wait(30): self.emit('HEARTBEAT')

    def update(self, **fields):
        with self.lock: self.fields.update(fields)

    def emit(self, event, **fields):
        with self.lock:
            self.fields.update(fields); state = dict(self.fields)
            elapsed = time.monotonic()-self.started
            s = self.ledger.summary(); done = state['calls_done']
            if self.base_done is None: self.base_done = done
            delta = done-self.base_done
            remaining = max(0,self.total-done-state['skipped'])
            eta = f'{elapsed/delta*remaining/60:.0f}m' if delta else '--'
            arms = ' '.join(f'{a}={n}/{self.per_arm}' for a,n in state['arms'].items())
            active = ' | '.join(f'{k} {v.get("status","WAITING_API")} '
                f'wait={time.monotonic()-v["started"]:.0f}s '
                f'model_chars={v.get("generated_content_chars",0)} '
                f'reasoning_chars={v.get("generated_reasoning_chars",0)}'
                for k,v in self.workers.items())
            stamp = datetime.now(ZoneInfo('Asia/Seoul')).strftime('%H:%M:%S KST')
            line = (f'[{stamp}] [{event}] {state["phase"]} | calls={done}/{self.total} '
                    f'proposals={state["proposal_done"]}/{self.proposals} {arms} '
                    f'invalid={state["invalid"]} skipped={state["skipped"]} | '
                    f'billed=${s["billed"]:.4f} reserved=${s["reserved"]:.4f} '
                    f'guard=${s["guard"]:.4f}/${self.ledger.cap:g} | elapsed={elapsed/60:.1f}m ETA~{eta} '
                    f'| {active or state.get("message","")}')
            print(line,flush=True)
            state.update(event=event,elapsed_seconds=elapsed,billing={k:s[k] for k in ('billed','reserved','guard')},
                         workers=self.workers,eta_note='character counts are not token counts')
            write_json(self.output/'progress.json',state)
            with (self.output/'progress.log').open('a',encoding='utf-8') as f: f.write(line+'\n')

    def worker(self, operation): return WorkerProgress(self,operation)


class WorkerProgress:
    def __init__(self,parent,operation):
        self.parent,self.operation = parent,operation
        self.state = {'started':time.monotonic(),'status':'WAITING_API'}
        with parent.lock: parent.workers[operation]=self.state

    def update_fields(self, **fields):
        with self.parent.lock: self.state.update(fields)

    def emit(self,event,**fields):
        self.update_fields(**fields); self.parent.emit(event)

    def close(self):
        with self.parent.lock: self.parent.workers.pop(self.operation,None)


class Client:
    def __init__(self, config, output, ledger, sender=None, secret=None, sleeper=None):
        self.config,self.output,self.ledger = config,output,ledger
        self.secret = secret if secret is not None else os.environ.get('OPENROUTER_API_KEY')
        if not self.secret and sender is None: raise StopRun('OPENROUTER_API_KEY is missing from environment and project .env')
        self.sender = sender; self.sleeper = sleeper
        self.key_guard = threading.Lock(); self.key_locks = {}
        self.cache = output/'cache'; self.cache.mkdir(exist_ok=True,parents=True)
        if sender is None:
            try:
                import truststore
                truststore.inject_into_ssl()
            except ImportError: pass

    def request(self,messages):
        m = self.config['model']
        return {'model':m['name'],'messages':messages,'temperature':m['temperature'],
                'max_tokens':m['max_output_tokens'],'response_format':{'type':'json_object'},
                'extra_body':{'provider':m['provider'],'reasoning':{'effort':m['reasoning_effort']}}}

    def validate(self,raw):
        usage = raw.get('usage') or {}
        if usage.get('is_byok') is not False: raise StopRun('Workspace-credit billing is not confirmed (is_byok=false). Saved response retained.')
        if raw.get('provider') != 'DeepInfra': raise StopRun('Response provider differs from pinned DeepInfra route')
        if raw.get('model') not in (self.config['model']['name'],'deepseek/deepseek-v4-flash-20260731'):
            raise StopRun('Returned model differs from the frozen model version')
        r = (usage.get('completion_tokens_details') or {}).get('reasoning_tokens')
        if type(r) is not int or r <= 0: raise StopRun('Requested low reasoning is not confirmed in response usage; saved response will not be resent')
        cost = usage.get('cost')
        if not isinstance(cost,(int,float)) or not math.isfinite(cost) or cost < 0:
            raise StopRun('Authoritative billing cost is unavailable; reservation retained')

    def _send(self,request,progress):
        if self.sender: return self.sender(request,progress)
        args = {'api_key':self.secret,'base_url':'https://openrouter.ai/api/v1','timeout':600,'max_retries':0,
                'default_headers':{'X-OpenRouter-Title':'taxonomy-contrastive-attribution'}}
        return asyncio.run(collect(args,request,deadline=600,progress=progress)).model_dump(mode='json')

    def call(self,messages,progress,cancel):
        key = sha(self.request(messages))
        with self.key_guard: lock = self.key_locks.setdefault(key,threading.Lock())
        with lock: return self._call(messages,progress,cancel)

    def safe_error(self,exc):
        message=str(exc)
        if self.secret: message=message.replace(self.secret,'[REDACTED]')
        return {'error_type':type(exc).__name__,'message':message[:2000]}

    def _call(self,messages,progress,cancel):
        request = self.request(messages); key = sha(request); path = self.cache/(key+'.json')
        if path.exists():
            cached = read_json(path)
            if cached['request'] != request: raise StopRun('Full cached request mismatch')
            self.validate(cached['raw_response']); return cached['raw_response'],key
        # UTF-8 byte upper bound plus ample framing allowance, not a claimed exact tokenizer.
        byte_bound = sum(len(m['content'].encode('utf-8')) for m in messages)+4096
        m = self.config['model']; prices = m['provider']['max_price']
        reserve = (byte_bound*prices['prompt']+m['max_output_tokens']*prices['completion'])/1e6
        for attempt in range(5):
            if cancel.is_set(): raise StopRun('Stopped before sending another request')
            hold = self.ledger.reserve(key,reserve)
            try:
                raw = self._send(request,progress)
            except APIStatusError as exc:
                code = exc.status_code
                if code in (400,401,402,403,404,413,422,429):
                    self.ledger.finish(hold,key)
                    append_jsonl(self.output/'provider_errors.jsonl',{'cache_key':key,'http_status':code,
                        'attempt':attempt+1,**self.safe_error(exc)})
                    if code != 429: raise StopRun(f'HTTP {code}: request rejected; no model failure scored. Inspect provider_errors.jsonl.') from None
                    if attempt == 4: raise StopRun('HTTP 429 rejected five requests; resume the same command later') from None
                    try: retry = float(exc.response.headers.get('retry-after','0'))
                    except (TypeError,ValueError): retry = 0
                    delay = min(900,max(30*2**attempt,retry if math.isfinite(retry) else 0))
                    progress.emit('RATE_LIMIT',status='WAITING_RATE_LIMIT',retry_seconds=delay)
                    if self.sleeper: self.sleeper(delay)
                    elif cancel.wait(delay): raise StopRun('Stopped during rate-limit backoff')
                    progress.update_fields(status='WAITING_API')
                    continue
                append_jsonl(self.output/'provider_errors.jsonl',{'cache_key':key,'http_status':code,
                    'attempt_id':hold,**self.safe_error(exc)})
                raise StopRun(f'HTTP {code}: billing uncertain; reservation retained, no automatic retry') from None
            except Exception as exc:
                # Transport errors/timeouts may already have generated billable tokens.
                append_jsonl(self.output/'provider_errors.jsonl',{'cache_key':key,'attempt_id':hold,
                    'generation_id':progress.state.get('generation_id'),**self.safe_error(exc)})
                raise StopRun('Transport/stream failed; billing uncertain. Reservation retained; inspect provider_errors.jsonl and provider usage before resuming.') from None
            # Save before settlement/validation so a crash never repeats a received generation.
            write_json(path,{'cache_key':key,'request':request,'raw_response':raw})
            cost = (raw.get('usage') or {}).get('cost')
            if isinstance(cost,(int,float)) and math.isfinite(cost) and cost >= 0:
                self.ledger.finish(hold,key,cost)
            self.validate(raw)
            if self.ledger.summary()['guard'] > self.ledger.cap:
                raise StopRun('Reported spend exceeds the local guard; further requests blocked')
            return raw,key


class QualityGate:
    def __init__(self,config): self.config = config

    def check(self,events):
        c = self.config; failed = [not r['valid'] for r in events]
        if sum(failed[-c['rolling_window_calls']:]) >= c['invalids_in_window_stop_at']:
            raise StopRun('Continuous quality gate: two invalid outputs in the most recent 20 calls; saved failures retained')
        n = c['consecutive_invalids_stop_at']
        if len(failed) >= n and all(failed[-n:]): raise StopRun('Continuous quality gate: consecutive invalid outputs')
        counts,errors = Counter(),Counter()
        for r in events:
            counts[r['arm']]+=1; errors[r['arm']]+=not r['valid']
        for arm,total in counts.items():
            if total >= c['per_condition_min_calls'] and errors[arm]/total > c['per_condition_invalid_fraction_stop_above']:
                raise StopRun('Continuous quality gate: invalid output fraction exceeds 5% for '+arm)
