"""Offline checks of information preservation, scoring, scheduling and billing."""
import contextlib
import io
import json
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

from taxonomy_experiment.io import read_json
from experiments.taxonomy_contrastive_attribution.runtime import load_rows
from experiments.hallu_errorbench_taxonomy import runner
from experiments.hallu_errorbench_taxonomy.design import HERE,ARMS,DATASETS,RELATIONS,canonical,sha,guidance,guide_for,messages,parse,score
from experiments.hallu_errorbench_taxonomy.encoding import encode,decode
from experiments.hallu_errorbench_taxonomy.results import paired_statistics,summarize,holm
from experiments.hallu_errorbench_taxonomy.runtime import Ledger,Progress,Client,StopRun,client_config


def record(case='x',dataset='agenterrorbench'):
    return {'case_id':case,'dataset':dataset,'split':'evaluation','framework':'test','group_id':case,
        'question':case,'native_steps':[1,2],'entities':['memory','action'] if dataset=='agenterrorbench' else ['Planner','Assistant'],
        'encoded':encode({'history':[{'step':1,'content':'first'},{'step':2,'content':'last'}]})}


def tasks_for(records,guides):
    result=[]
    for i,r in enumerate(records):
        for arm in ARMS[i%4:]+ARMS[:i%4]:
            result.append({'order':len(result),'case_id':r['case_id'],'dataset':r['dataset'],'split':'evaluation','arm':arm,
                'prompt_sha256':sha(canonical(messages(r,guide_for(r['dataset'],arm,guides)))),'input_proxy_tokens':100})
    return result


class FakeClient:
    def __init__(self):self.calls=[];self.lock=threading.Lock();self.active=set()
    def call(self,prompt,worker,cancel):
        body=json.loads(prompt[-1]['content'].split('\n\nTaxonomy guidance:\n')[0]);case=body['question']
        with self.lock:
            if case in self.active:raise AssertionError('Same trajectory sent concurrently')
            self.active.add(case);self.calls.append(case)
        response={'choices':[{'finish_reason':'stop','message':{'content':json.dumps({'when':1,'who':body['entities'][0],'reason':'Visible evidence.'})}}],
            'usage':{'cost':0,'prompt_tokens':100,'completion_tokens':20,'prompt_tokens_details':{'cached_tokens':0}}}
        with self.lock:self.active.remove(case)
        return response,sha(canonical(prompt))


class DesignTests(unittest.TestCase):
    def test_full_membership_and_manifest(self):
        plan,data,manifest,_=runner.snapshot()
        self.assertEqual(plan['scope'],'full');self.assertEqual(plan['cases'],{'agenthallu':240,'agenterrorbench':171})
        self.assertEqual(len(manifest),1644);self.assertEqual(plan['budget']['hard_cap_usd'],8)
        self.assertEqual(len({r['group_id'] for r in data if r['dataset']=='agenterrorbench'}),91)

    def test_all_decoded_visible_records_match_audited_digest(self):
        data=load_rows(HERE/'prepared/inputs.jsonl');audits={r['case_id']:r for r in read_json(HERE/'prepared/source_audit.json')['cases']}
        for r in data:self.assertEqual(sha(canonical(decode(r['encoded']))),audits[r['case_id']]['visible_sha256'])

    def test_nested_and_malformed_memory_preserves_exact_text(self):
        text='<memory>outer<memory>inner</memory>tail</memory>'*8
        for v in ({'a':text,'b':text},['<memory>unclosed','</memory>unmatched'],{'a':'long repeated string '*30,'b':'long repeated string '*30}):
            self.assertEqual(decode(encode(v)),v)

    def test_no_extra_reference_keys_or_gold_fields_reach_prompt(self):
        r=record();text=messages(r,'')
        r.update(gold_step=2,gold_who='SECRET',annotation='SECRET',reference_reason='SECRET')
        self.assertEqual(messages(r,''),text);self.assertNotIn('SECRET',canonical(messages(r,'')))

    def test_actual_own_foreign_swap_and_identical_merge(self):
        guides,provenance=guidance()
        for ds in DATASETS:
            other=next(d for d in DATASETS if d!=ds)
            self.assertEqual(guide_for(ds,'own',guides),guide_for(other,'foreign',guides))
            self.assertEqual(guide_for(ds,'merged',guides),guides['merged'])
            self.assertEqual(guide_for(ds,'no_label',guides),'')
        self.assertEqual(len(provenance['hallu']),14);self.assertEqual(len(provenance['error']),17)
        valid_h={r['id'] for r in provenance['hallu']};valid_e={r['id'] for r in provenance['error']}
        for relation in RELATIONS:
            self.assertTrue(set(relation['hallu'])<=valid_h);self.assertTrue(set(relation['error'])<=valid_e)
            self.assertNotEqual(relation['type'],'equivalence')
        for r in provenance['hallu']+provenance['error']:self.assertIn(r['definition'],guides['merged'])

    def test_same_module_candidate_space_in_every_condition(self):
        guides,_=guidance();r=record()
        for arm in ARMS:
            body=json.loads(messages(r,guide_for(r['dataset'],arm,guides))[-1]['content'].split('\n\nTaxonomy guidance:\n')[0])
            self.assertEqual(body['entities'],r['entities']);self.assertEqual(body['native_steps'],[1,2])

    def test_independent_axis_scoring_and_strict_native_step(self):
        r=record();g={'when':2,'who':'memory','who_eligible':True}
        p=parse({'when':'1','who':'memory','reason':'Evidence.'},r)
        self.assertEqual(score(p,g),{'when':False,'who':True})
        self.assertIsNone(parse({'when':True,'who':'memory','reason':'Evidence.'},r)['when'])
        self.assertIsNone(parse({'when':999,'who':'memory','reason':'Evidence.'},r)['when'])
        self.assertEqual(parse({'when':1,'who':'plan','reason':'Evidence.'},{**r,'entities':['planning']})['who'],'planning')
        self.assertIsNone(score(None,{**g,'who_eligible':False})['who'])

    def test_check_never_initializes_inference_client(self):
        with patch.object(runner,'Client',side_effect=AssertionError('Network client constructed')):
            result=runner.preflight()
        self.assertEqual(result['paid_calls_made_by_check'],0);self.assertFalse(result['live_endpoint_validated'])


class RuntimeTests(unittest.TestCase):
    def test_run_wrapper_completes_and_second_run_uses_saved_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);guides=guidance()[0];records=[record('h','agenthallu'),record('e')];tasks=tasks_for(records,guides)
            gold=[{'case_id':r['case_id'],'when':1,'who':r['entities'][0],'who_eligible':True,'who_kind':'test','category':'test'} for r in records]
            plan={'inference':{'model':'google/gemini-2.5-flash','temperature':0,'max_output_tokens':512},'budget':{'hard_cap_usd':8},'limitations':['offline integration fixture']}
            identity={'files_sha256':{},'version':'offline integration fixture'};sent=[]
            def freeze_fixture(ignored,output):
                from experiments.hallu_errorbench_taxonomy.prepare import write_rows
                frozen=output/'frozen/experiments/hallu_errorbench_taxonomy/prepared';frozen.mkdir(parents=True,exist_ok=True)
                for name,values in [('inputs',records),('gold',gold),('request_manifest',tasks)]:write_rows(frozen/(name+'.jsonl'),values)
                (frozen/'guidance').mkdir(exist_ok=True)
                for name,text in guides.items():(frozen/'guidance'/(name+'.txt')).write_text(text,encoding='utf-8')
            def make_client(config,output,ledger):
                def sender(request,worker):
                    sent.append(request);body=json.loads(request['messages'][-1]['content'].split('\n\nTaxonomy guidance:\n')[0])
                    return {'model':'google/gemini-2.5-flash','provider':'Google AI Studio',
                        'choices':[{'finish_reason':'stop','message':{'content':json.dumps({'when':1,'who':body['entities'][0],'reason':'Visible evidence.'})}}],
                        'usage':{'cost':.001,'is_byok':False,'prompt_tokens':100,'completion_tokens':20,'completion_tokens_details':{'reasoning_tokens':0}}}
                return Client(config,output,ledger,sender=sender,secret='offline-only')
            with patch.object(runner,'ARTIFACTS',root/'artifacts'),patch.object(runner,'snapshot',return_value=(plan,records,tasks,identity)),\
                 patch.object(runner,'freeze_files',side_effect=freeze_fixture),patch.object(runner,'Client',side_effect=make_client),\
                 patch.object(runner,'_load_project_dotenv'),patch.dict('os.environ',{'OPENROUTER_API_KEY':'offline-only'}),contextlib.redirect_stdout(io.StringIO()):
                first=runner.run();second=runner.run()
            self.assertEqual(first['status'],'COMPLETE');self.assertEqual(second['status'],'COMPLETE');self.assertEqual(len(sent),8)
            self.assertAlmostEqual(second['billed_usd'],.008);self.assertTrue(Path(second['result_file']).exists())

    def test_schedule_finishes_each_case_without_duplicates_and_resumes(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp);ledger=Ledger(out/'ledger.jsonl',8);guides=guidance()[0];records=[record('a'),record('b'),record('c')];tasks=tasks_for(records,guides)
            progress=Progress(out,ledger,{a:3 for a in ARMS},{'agenterrorbench':12});client=FakeClient()
            with contextlib.redirect_stdout(io.StringIO()):
                study=runner.Study({},records,tasks,out,client,progress,'evaluation',guides);study.stage()
                again=runner.Study({},records,tasks,out,client,progress,'evaluation',guides);again.stage()
            self.assertEqual(len(client.calls),12);self.assertEqual(len(load_rows(out/'predictions.jsonl')),12)
            self.assertEqual(len(again.rows),12);self.assertTrue(all(r['json_valid'] for r in again.rows.values()))

    def test_budget_guard_survives_restart_and_unsettled_bill_blocks_duplicate(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'ledger.jsonl';ledger=Ledger(path,8);hold=ledger.reserve('a',7.9)
            with self.assertRaises(StopRun):Ledger(path,8).reserve('b',.2)
            with self.assertRaises(StopRun):Ledger(path,8).reserve('a',.01)
            ledger.finish(hold,'a',.3);self.assertAlmostEqual(Ledger(path,8).summary()['billed'],.3)

    def test_actual_client_cache_and_workspace_billing_with_fake_sender(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp);ledger=Ledger(out/'ledger.jsonl',8);progress=Progress(out,ledger,{'own':1},{'agenterrorbench':1})
            calls=[]
            def sender(request,worker):
                calls.append(request)
                return {'model':'google/gemini-2.5-flash','provider':'Google AI Studio','choices':[{'finish_reason':'stop','message':{'content':'{}'}}],
                    'usage':{'cost':.001,'is_byok':False,'completion_tokens_details':{'reasoning_tokens':0}}}
            config=client_config({'inference':{'model':'google/gemini-2.5-flash','temperature':0,'max_output_tokens':512}})
            client=Client(config,out,ledger,sender=sender,secret='fake-offline-only');worker=progress.worker('test');cancel=threading.Event()
            with contextlib.redirect_stdout(io.StringIO()):
                client.call([{'role':'user','content':'offline fixture'}],worker,cancel)
                client.call([{'role':'user','content':'offline fixture'}],worker,cancel)
            self.assertEqual(len(calls),1);self.assertAlmostEqual(ledger.summary()['billed'],.001);self.assertFalse(ledger.summary()['holds'])
            raw=sender({},None);raw['usage']['is_byok']=True
            with self.assertRaises(StopRun):client.validate(raw)
            raw['usage']['is_byok']=False;raw['usage']['completion_tokens_details']['reasoning_tokens']=1
            with self.assertRaises(StopRun):client.validate(raw)


class StatisticsTests(unittest.TestCase):
    def test_repeated_tasks_are_two_clusters_not_four_independent_cases(self):
        result=paired_statistics([1,1,1,1],['a','a','b','b'],bootstrap_draws=100)
        self.assertEqual(result['question_clusters'],2);self.assertEqual(result['paired_cluster_p'],.5)
        self.assertEqual(result['paired_cluster_bootstrap_95_percent_pp'],[100,100])

    def test_holm_accounts_for_all_four_comparisons(self):
        values=[{'paired_cluster_p':p} for p in [.01,.03,.04,.9]];holm(values)
        self.assertEqual([round(v['holm_p'],2) for v in values],[.04,.09,.09,.9])

    def test_report_keeps_invalid_answers_in_denominator_and_no_joint(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp);ledger=Ledger(out/'ledger.jsonl',8);records=[record('h','agenthallu'),record('e')];guides=guidance()[0]
            tasks=tasks_for(records,guides);rows={(t['case_id'],t['arm']):{**t,'prediction':None,'json_valid':False,'usage':{},'api_seconds':0} for t in tasks}
            gold=[{'case_id':r['case_id'],'when':1,'who':r['entities'][0],'who_eligible':True,'who_kind':'test','category':'test'} for r in records]
            plan={'limitations':['offline fixture']}
            result=summarize(plan,records,gold,rows,out,ledger)
            self.assertFalse(result['joint_scored']);self.assertFalse(result['what_scored'])
            for ds in DATASETS:
                for arm in ARMS:
                    c=result['datasets'][ds]['conditions'][arm];self.assertEqual(c['n'],1);self.assertEqual(c['when_correct'],0);self.assertEqual(c['invalid_json'],1)
            self.assertEqual(len(result['primary_when_contrasts']),4);self.assertTrue((out/'RESULTS_KO.md').exists())
            rows.pop(next(iter(rows)))
            with self.assertRaises(StopRun):summarize(plan,records,gold,rows,out,ledger)


if __name__=='__main__':unittest.main()
