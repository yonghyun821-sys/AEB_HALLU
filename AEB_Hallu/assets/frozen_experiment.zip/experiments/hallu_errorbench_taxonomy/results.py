"""Dataset-specific attribution reports; question-cluster paired statistics."""
import csv
import itertools
import random
from collections import defaultdict

from taxonomy_experiment.io import write_json
from .design import ARMS,DATASETS,score
from .runtime import StopRun


def paired_statistics(differences,groups,seed=20261102,bootstrap_draws=10000,permutation_draws=50000):
    if not differences or len(differences)!=len(groups):raise ValueError('Invalid paired cluster inputs')
    clusters=defaultdict(list)
    for g,d in zip(groups,differences,strict=True):clusters[g].append(d)
    values=[(sum(v),len(v)) for _,v in sorted(clusters.items())];rng=random.Random(seed)
    boots=[]
    for _ in range(bootstrap_draws):
        sample=rng.choices(values,k=len(values));boots.append(100*sum(s for s,n in sample)/sum(n for s,n in sample))
    boots.sort();lo=boots[max(0,int(.025*len(boots))-1)];hi=boots[max(0,int(.975*len(boots))-1)]
    sums=[s for s,n in values if s];observed=abs(sum(sums))
    if not sums:p=1.;method='no discordant cluster contribution'
    elif len(sums)<=18:
        extreme=sum(abs(sum(x*y for x,y in zip(sums,signs,strict=True)))>=observed for signs in itertools.product((-1,1),repeat=len(sums)))
        p=extreme/(2**len(sums));method='exact paired cluster sign-flip'
    else:
        extreme=sum(abs(sum(s if rng.getrandbits(1) else -s for s in sums))>=observed for _ in range(permutation_draws))
        p=(extreme+1)/(permutation_draws+1);method=f'Monte Carlo paired cluster sign-flip ({permutation_draws} draws, plus-one p)'
    return {'when_delta_pp':100*sum(differences)/len(differences),'improved':differences.count(1),'regressed':differences.count(-1),
        'question_clusters':len(values),'paired_cluster_bootstrap_95_percent_pp':[lo,hi],'paired_cluster_p':p,'test':method}


def holm(contrasts):
    previous=0
    for rank,index in enumerate(sorted(range(len(contrasts)),key=lambda i:contrasts[i]['paired_cluster_p'])):
        previous=max(previous,min(1,(len(contrasts)-rank)*contrasts[index]['paired_cluster_p']));contrasts[index]['holm_p']=previous


def summarize(plan,data,gold,rows,output,ledger):
    expected={(r['case_id'],a) for r in data for a in ARMS}
    if set(rows)!=expected:raise StopRun('Evaluation incomplete; no final accuracy report generated')
    labels={r['case_id']:r for r in gold}
    hits={(r['case_id'],a):score(rows[r['case_id'],a]['prediction'],labels[r['case_id']]) for r in data for a in ARMS}
    reports={};contrasts=[]
    for ds in DATASETS:
        selected=[r for r in data if r['dataset']==ds];eligible=sum(labels[r['case_id']]['who_eligible'] for r in selected)
        conditions={}
        for a in ARMS:
            clusters=defaultdict(list)
            for r in selected:clusters[r['group_id']].append(int(hits[r['case_id'],a]['when']))
            conditions[a]={'n':len(selected),'when_correct':sum(hits[r['case_id'],a]['when'] for r in selected),
                'who_n':eligible,'who_correct':sum(hits[r['case_id'],a]['who'] is True for r in selected),
                'question_macro_when_percent':100*sum(sum(v)/len(v) for v in clusters.values())/len(clusters),
                'invalid_json':sum(not rows[r['case_id'],a]['json_valid'] for r in selected),
                'field_issues':sum(bool((rows[r['case_id'],a]['prediction'] or {}).get('format_issues',[])) for r in selected)}
        for left,right in [('own','foreign'),('merged','own')]:
            differences=[int(hits[r['case_id'],left]['when'])-int(hits[r['case_id'],right]['when']) for r in selected]
            contrasts.append({'dataset':ds,'contrast':left+' - '+right,**paired_statistics(differences,[r['group_id'] for r in selected])})
        baselines={name:sum(r['native_steps'][index if len(r['native_steps'])>1 else 0]==labels[r['case_id']]['when'] for r in selected)
            for name,index in [('first',0),('last',-1),('penultimate',-2)]}
        informative=[r for r in selected if len(r['native_steps'])>=2]
        by_framework={fw:{a:{'n':sum(r['framework']==fw for r in selected),
            'when_correct':sum(hits[r['case_id'],a]['when'] for r in selected if r['framework']==fw),
            'who_n':sum(labels[r['case_id']]['who_eligible'] for r in selected if r['framework']==fw),
            'who_correct':sum(hits[r['case_id'],a]['who'] is True for r in selected if r['framework']==fw)} for a in ARMS} for fw in sorted({r['framework'] for r in selected})}
        by_category={cat:{a:{'n':sum(labels[r['case_id']]['category']==cat for r in selected),
            'when_correct':sum(hits[r['case_id'],a]['when'] for r in selected if labels[r['case_id']]['category']==cat)} for a in ARMS}
            for cat in sorted({labels[r['case_id']]['category'] for r in selected})}
        reports[ds]={'conditions':conditions,'question_groups':len({r['group_id'] for r in selected}),
            'who_kind':'derived_step_speaker' if ds=='agenthallu' else 'native_responsible_module',
            'position_baselines_correct':baselines,'single_candidate_cases':len(selected)-len(informative),
            'nontrivial_trace_sensitivity':{a:{'n':len(informative),'when_correct':sum(hits[r['case_id'],a]['when'] for r in informative)} for a in ARMS},
            'by_framework':by_framework,'by_native_category_descriptive':by_category}
    holm(contrasts);billing={k:v for k,v in ledger.summary().items() if k!='holds'}
    report={'status':'COMPLETE','datasets':reports,'primary_when_contrasts':contrasts,'billing':billing,
        'what_scored':False,'joint_scored':False,'accuracy_gate_used':False,'limitations':plan['limitations']}
    write_json(output/'RESULTS.json',report)
    lines=['# Hallu–AgentErrorBench taxonomy attribution results','',
        '두 데이터셋의 native When을 각각 채점했습니다. What·joint 정확도는 계산하지 않았습니다.','',
        '| 데이터셋 | 조건 | When | 보조 지표 | JSON 오류 |','|---|---|---:|---:|---:|']
    for ds,values in reports.items():
        for a,c in values['conditions'].items():
            who=f'{100*c["who_correct"]/c["who_n"]:.2f}% ({c["who_correct"]}/{c["who_n"]})' if c['who_n'] else 'N/A'
            lines.append(f'| {ds} | {a} | {100*c["when_correct"]/c["n"]:.2f}% ({c["when_correct"]}/{c["n"]}) | {who} | {c["invalid_json"]} |')
    lines+=['','Hallu 보조 지표는 정답 단계의 발화자에서 유도한 값이며 독립적인 책임 Who 정답이 아닙니다. AEB 보조 지표는 원본 책임 모듈 정답입니다. 서로 합산하지 않습니다.','',
        '주요 비교: 같은 과제를 묶은 paired cluster bootstrap CI 및 sign-flip 검정, 네 비교 전체에 Holm 보정.','']
    for c in contrasts:
        lo,hi=c['paired_cluster_bootstrap_95_percent_pp']
        lines.append(f'- {c["dataset"]} / {c["contrast"]}: {c["when_delta_pp"]:+.2f}pp; 95% CI [{lo:+.2f}, {hi:+.2f}]; 개선 {c["improved"]}, 악화 {c["regressed"]}; Holm p={c["holm_p"]:.4g}.')
    lines+=['',f'새 실험 청구액: ${billing["billed"]:.4f} / ${ledger.cap:g}. 이전 실험 비용은 이 한도에 포함하지 않습니다.','',
        '기존 실험에서 노출된 표본을 사용한 탐색적 결과입니다. Merged−Own 차이는 정의 추가와 관계 지침 전체의 효과이며, 단순 union 대비 병합 관계만의 효과는 분리하지 못합니다.','',
        '| 데이터셋 | 프레임워크/환경 | 조건 | N | When |','|---|---|---|---:|---:|']
    for ds,values in reports.items():
        for fw,arms in values['by_framework'].items():
            for a,c in arms.items():lines.append(f'| {ds} | {fw} | {a} | {c["n"]} | {100*c["when_correct"]/c["n"]:.2f}% |')
        lines+=['',f'{ds} 위치 기준선: '+', '.join(f'{k}={v}/{values["conditions"]["own"]["n"]}' for k,v in values['position_baselines_correct'].items())+'.','']
    (output/'RESULTS_KO.md').write_text('\n'.join(lines),encoding='utf-8')
    with (output/'per_case_scores.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['dataset','case_id','group_id','framework','category','arm','when_gold','when_pred','when_correct','who_kind','who_gold','who_pred','who_eligible','who_correct','json_valid'])
        for r in data:
            g=labels[r['case_id']]
            for a in ARMS:
                pred=rows[r['case_id'],a]['prediction'] or {}
                writer.writerow([r['dataset'],r['case_id'],r['group_id'],r['framework'],g['category'],a,g['when'],pred.get('when'),hits[r['case_id'],a]['when'],g['who_kind'],g['who'],pred.get('who'),g['who_eligible'],hits[r['case_id'],a]['who'],rows[r['case_id'],a]['json_valid']])
    write_json(output/'resource_summary.json',{'billing':billing,
        'prompt_tokens':sum(r['usage'].get('prompt_tokens',0) for r in rows.values()),
        'completion_tokens':sum(r['usage'].get('completion_tokens',0) for r in rows.values()),
        'cached_tokens':sum((r['usage'].get('prompt_tokens_details') or {}).get('cached_tokens',0) for r in rows.values()),
        'api_seconds_total':sum(r['api_seconds'] for r in rows.values())})
    return report
