"""Offline-only membership, exact-text encoding, prompt hashes and forecasts."""
import argparse
import collections
import json
import re
import sys
import unicodedata
from pathlib import Path

import tiktoken

sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from taxonomy_experiment.io import read_json,write_json
from experiments.step_accuracy_v2.data import digest
from experiments.taxonomy_contrastive_attribution.runtime import load_rows
from experiments.hallu_errorbench_taxonomy.design import ROOT,HERE,ARMS,DATASETS,MODULES,SEED,sha,canonical,guidance,guide_for,messages
from experiments.hallu_errorbench_taxonomy.encoding import encode,decode

HALLU=ROOT/'experiments/agenthallu_taxonomy_all_at_once/prepared'
AEB=ROOT/'experiments/deepseek_step_relation_merge/artifacts/prepared/5fb161d6a810591c'


def group_id(question):
    return sha(re.sub(r'\s+',' ',unicodedata.normalize('NFKC',question)).strip().casefold())


def write_rows(path,values):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(''.join(json.dumps(v,ensure_ascii=True,sort_keys=True,separators=(',',':'))+'\n' for v in values),encoding='utf-8')


def prepare(scope='economy'):
    if (HERE/'artifacts/active_run.json').exists():raise ValueError('Study already started; refusing to change frozen membership')
    if scope not in ('economy','full'):raise ValueError('Invalid sample scope')
    source_paths=set()
    def read_rows(path):
        source_paths.add(path);return load_rows(path)
    hallu=read_rows(HALLU/'inputs.jsonl');hgold={r['case_id']:r for r in read_rows(HALLU/'gold.jsonl')}
    sources={r['case_id']:r for r in read_rows(HALLU/'source_manifest.jsonl')}
    hallu=[r for r in hallu if r['split']=='evaluation']
    if len(hallu)!=240 or len({r['group_id'] for r in hallu})!=240:raise ValueError('Expected fixed Hallu-240 research subset')
    notes=[]
    if scope=='economy':
        groups=collections.defaultdict(list)
        for r in hallu:groups[r['framework']].append(r)
        quotas={k:len(v)//2 for k,v in groups.items()}
        for k in sorted(groups,key=lambda k:(-(len(groups[k])/2-quotas[k]),k))[:120-sum(quotas.values())]:quotas[k]+=1
        chosen={r['case_id'] for k,v in groups.items() for r in sorted(v,key=lambda r:sha(SEED+':hallu:'+r['case_id']))[:quotas[k]]}
        notes.extend({'dataset':'agenthallu','case_id':r['case_id'],'reason':'outside hash-selected 120-case proportional framework subset'} for r in hallu if r['case_id'] not in chosen)
        hallu=[r for r in hallu if r['case_id'] in chosen]
    data=[];gold=[];audits=[]
    for r in hallu:
        native=r['native_steps'];ref=hgold[r['case_id']]
        if ref['hallucination_step'] not in native:raise ValueError('Unaddressable Hallu target')
        origin=sources[r['case_id']]
        raw_path=ROOT/'experiments/taxonomy_dataset_review_20261102/sources/agenthallu'/origin['source_path']
        if sha(raw_path.read_bytes())!=origin['source_sha256']:raise ValueError('Pinned Hallu raw source changed')
        source_paths.add(raw_path)
        roles=sorted({s['role'] for s in r['history'] if isinstance(s.get('role'),str)})
        visible={'history':r['history']}
        data.append({'case_id':r['case_id'],'dataset':'agenthallu','split':'evaluation','framework':r['framework'],
            'group_id':r['group_id'],'question':r['question'],'native_steps':native,'entities':roles,'encoded':encode(visible)})
        gold.append({'case_id':r['case_id'],'when':ref['hallucination_step'],'who':ref['step_speaker'],
            'who_eligible':ref['speaker_eligible'],'who_kind':'derived_step_speaker','category':ref['subcategory']})
        audits.append({'case_id':r['case_id'],'source':str(raw_path.relative_to(ROOT).as_posix()),
            'visible_sha256':sha(canonical(visible)),'decoded_sha256':sha(canonical(decode(data[-1]['encoded'])))})
    source_paths.add(AEB/'sample_manifest.json');manifest=read_json(AEB/'sample_manifest.json')
    old=read_rows(AEB/'inputs.jsonl');old_gold=read_rows(AEB/'gold.jsonl')
    if digest(old)!=manifest['inputs_sha256'] or digest(old_gold)!=manifest['gold_sha256']:raise ValueError('Audited AEB visible/native-step source changed')
    refs={r['trajectory_id']:r for r in old_gold if r['dataset']=='agenterrorbench'}
    aeb=[r for r in old if r['dataset']=='agenterrorbench']
    if len(aeb)!=171 or len(refs)!=171:raise ValueError('Expected audited AEB-171 pool')
    labels={}
    for path in sorted((ROOT/'datasets/agenterrorbench/Label').glob('*.json')):
        source_paths.add(path)
        for label in read_json(path):
            if label['trajectory_id'] in labels:raise ValueError('Duplicate AEB annotation ID')
            labels[label['trajectory_id']]=label
    raw_paths={p.stem:p for p in (ROOT/'datasets/agenterrorbench/Original_Failure_Trajectory').glob('*/*.json')}
    included={r['trajectory_id'] for r in aeb}
    for tid,label in labels.items():
        if tid in included:continue
        reason='outside previously audited AEB-171 membership; preserve historical exclusions'
        if tid not in raw_paths:reason='official label has no matching local raw trajectory'
        else:
            raw=read_json(raw_paths[tid]);n=sum(m.get('role')=='user' for m in raw.get('messages',[]))
            if type(label.get('critical_failure_step')) is not int or not 1<=label['critical_failure_step']<=n:
                reason='native gold step is not addressable in visible trajectory'
        notes.append({'dataset':'agenterrorbench','trajectory_id':tid,'reason':reason})
    if scope=='economy':
        groups=collections.defaultdict(list)
        for r in aeb:groups[group_id(r['task'])].append(r)
        selected={min(v,key=lambda r:sha(SEED+':aeb:'+r['trajectory_id']))['trajectory_id'] for v in groups.values()}
        notes.extend({'dataset':'agenterrorbench','trajectory_id':r['trajectory_id'],'reason':'same normalized task; representative selected by fixed ID hash, without labels or predictions'} for r in aeb if r['trajectory_id'] not in selected)
        aeb=[r for r in aeb if r['trajectory_id'] in selected]
        if len(aeb)!=91:raise ValueError('Expected AEB 91 unique task groups')
    for r in aeb:
        tid=r['trajectory_id'];ref=refs[tid];label=labels[tid]
        native=[int(s) for s in ref['native_step_ids']]
        target=int(ref['native_gold_step_id']);module={'plan':'planning'}.get(label['critical_failure_module'],label['critical_failure_module'])
        if target!=label['critical_failure_step'] or module not in MODULES or target not in native or len(native)!=len(set(native)) or len(native)!=len(r['steps']):
            raise ValueError('Invalid AEB annotation/native-coordinate mapping')
        raw_path=raw_paths[tid];source_paths.add(raw_path);raw=read_json(raw_path)['messages']
        if len(raw)!=2*len(native):raise ValueError('AEB raw/normalized decision mapping differs')
        history=[]
        for i,(coord,s) in enumerate(zip(native,r['steps'],strict=True)):
            if raw[2*i]['role']!='user' or raw[2*i+1]['role']!='assistant' or raw[2*i+1]['content']!=s['agent_output']:
                raise ValueError('Raw AEB assistant text was not preserved')
            explicit=re.search(r'you are now at step\s+(\d+)',raw[2*i]['content'],re.I)
            if explicit and int(explicit.group(1))!=coord:raise ValueError('Native AEB step differs from explicit raw message')
            history.append({'step':coord,**{k:s[k] for k in ('observation','available_actions','visible_memory_blocks','agent_output')}})
        visible={'context':r['context'],'history':history};case='aeb:'+sha(tid)[:20]
        data.append({'case_id':case,'dataset':'agenterrorbench','split':'evaluation','framework':r['domain'],
            'group_id':group_id(r['task']),'question':r['task'],'native_steps':native,'entities':list(MODULES),'encoded':encode(visible)})
        annotation=next((s for s in label.get('step_annotations',[]) if s.get('step')==target),{})
        detail=annotation.get(label['critical_failure_module'],annotation.get(module,annotation.get('plan',{}))) or {}
        gold.append({'case_id':case,'when':target,'who':module,'who_eligible':True,'who_kind':'native_responsible_module',
            'category':detail.get('failure_type','unavailable'),'trajectory_id':tid})
        audits.append({'case_id':case,'source':raw_path.relative_to(ROOT).as_posix(),'visible_sha256':sha(canonical(visible)),
            'decoded_sha256':sha(canonical(decode(data[-1]['encoded']))),'raw_assistant_exact':True,
            'representation_limit':'existing audited normalization of repeated user instructions/PDF-binary markers; assistant outputs and visible memory preserved'})
    data.sort(key=lambda r:sha(SEED+':order:'+r['case_id']))
    guides,provenance=guidance();out=HERE/'prepared';out.mkdir(exist_ok=True)
    for name,text in guides.items():
        p=out/'guidance'/(name+'.txt');p.parent.mkdir(exist_ok=True);p.write_text(text,encoding='utf-8')
    enc=tiktoken.get_encoding('o200k_base');requests=[]
    for i,r in enumerate(data):
        for arm in ARMS[i%4:]+ARMS[:i%4]:
            prompt=messages(r,guide_for(r['dataset'],arm,guides))
            nt=sum(len(enc.encode(m['content'],disallowed_special=())) for m in prompt)+32
            requests.append({'order':len(requests),'case_id':r['case_id'],'dataset':r['dataset'],'split':'evaluation','arm':arm,
                'prompt_sha256':sha(canonical(prompt)),'input_proxy_tokens':nt})
    for name,rows in [('inputs',data),('gold',gold),('request_manifest',requests)]:write_rows(out/(name+'.jsonl'),rows)
    source_paths.add(ROOT/'taxonomies/agenterror_taxonomy.json')
    source_paths.add(ROOT/'experiments/agenthallu_taxonomy_all_at_once/design.py')
    write_json(out/'source_audit.json',{'files':{p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted(source_paths)},
        'cases':audits,'exclusions':notes,'historical_exposure':'Both pools have appeared in earlier studies. This is an exploratory paired study, not a fresh confirmatory holdout.',
        'selection_uses_prediction_results':False,'paid_calls_made':0})
    write_json(out/'merge_provenance.json',{'method':'source-preserving definitions plus typed evidence boundaries, v1',
        'sources':{'hallu':'https://arxiv.org/html/2601.06818v1#S4.T2','error':'https://arxiv.org/abs/2509.25370'},
        'independent_human_semantic_review':False,'case_labels_used_to_author_relations':False,**provenance})
    write_json(out/'prompt_previews.json',{ds:{a:messages(next(r for r in data if r['dataset']==ds),guide_for(ds,a,guides)) for a in ARMS} for ds in DATASETS})
    n=len(requests);nt=sum(t['input_proxy_tokens'] for t in requests)
    forecasts={}
    for name,mult,out_tokens,cache_fraction in [('planning_no_cache',1.15,100,0),('stress_no_cache',1.5,512,0),('illustrative_40pct_cached',1.15,100,.4)]:
        forecasts[name]={'input_multiplier':mult,'mean_output_tokens':out_tokens,'assumed_cached_input_fraction':cache_fraction,
            'usd':nt*mult*(.30*(1-cache_fraction)+.03*cache_fraction)/1e6+n*out_tokens*2.50/1e6}
    plan={'version':'hallu-errorbench-v1','status':'OFFLINE_PREPARED_LIVE_NOT_VALIDATED','scope':scope,'conditions':list(ARMS),
        'cases':dict(collections.Counter(r['dataset'] for r in data)),'question_groups':{ds:len({r['group_id'] for r in data if r['dataset']==ds}) for ds in DATASETS},
        'calls':n,'development_paid_calls':0,'all_requests_fresh':True,
        'inference':{'model':'google/gemini-2.5-flash','temperature':0,'reasoning_enabled':False,'max_output_tokens':512,'workers':2,'heartbeat_seconds':30},
        'schedule':'two trajectories concurrently; four rotated arms sequentially within each trajectory; cache savings not guaranteed',
        'budget':{'target_usd':4 if scope=='economy' else 5,'hard_cap_usd':5 if scope=='economy' else 8,
            'scope':'new study only, one durable ledger across both datasets and all resumes; excludes completed historical studies',
            'input_usd_per_million':.30,'output_usd_per_million':2.50,'cache_read_usd_per_million':.03,
            'pricing_checked_on':'2026-11-02','pricing_source':'https://openrouter.ai/api/v1/models/google/gemini-2.5-flash/endpoints',
            'input_proxy_tokens':nt,'forecast':forecasts,'estimator':'o200k_base proxy, not Gemini tokenizer. Cache discounts are uncertain. Hard cap can stop an incomplete run.'},
        'statistics':{'primary':'native exact When reported separately per dataset','contrasts':['own - foreign','merged - own'],
            'family':'Holm correction over four dataset-specific When contrasts','resampling':'paired normalized-question cluster bootstrap 10000 draws',
            'test':'paired cluster sign-flip, exact for <=18 clusters, otherwise Monte Carlo 50000 draws, seed fixed',
            'secondary':['AEB native responsible-module accuracy','Hallu derived step-speaker accuracy on eligible subset only'],
            'sensitivity':'When on traces with >=2 candidates, descriptive only; fixed first/last/penultimate position baselines',
            'what_scored':False,'joint_scored':False},
        'time_forecast_minutes_at_2_to_5_seconds_per_call':[n*2/2/60,n*5/2/60],
        'guidance_proxy_tokens':{k:len(enc.encode(t,disallowed_special=())) for k,t in guides.items()},
        'limitations':['historically exposed pools, exploratory study','merged versus own compares a package, not isolated alignment benefit; no union control',
            'fixed Hallu-first order inside merged; ordering not isolated','AEB module label space structurally matches its own taxonomy; candidate names given in every arm',
            'exact When is a localization metric, not validation of the free-text causal reason','text references are lossless but their effect on model comprehension is unmeasured'],
        'hashes':{p.relative_to(out).as_posix():sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()},
        'paid_calls_made_during_preparation':0}
    write_json(HERE/'study_plan.json',plan)
    return plan


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--scope',choices=('economy','full'),default='economy');args=parser.parse_args()
    plan=prepare(args.scope)
    print(json.dumps({k:plan[k] for k in ('status','scope','cases','question_groups','calls','budget','time_forecast_minutes_at_2_to_5_seconds_per_call')},indent=2))
