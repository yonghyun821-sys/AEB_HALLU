# Hallu–AgentErrorBench 양방향 실험

[전체 설계 설명](PROTOCOL_KO.md)

**실행 직전 준비. 유료 실험은 아직 시작하지 않음.**

- Hallu 240 + AEB 171, 네 조건, 총 1,644회.
- No label / Own / Foreign / 새 Merged. 양방향에서 Own·Foreign 교환, 같은 merged 사용.
- Gemini 2.5 Flash, thinking off, 출력 상한 512, 두 기록 병렬·기록 안 네 조건 순차.
- 목표 $5, 새 실험 전체 상한 $8. 할인 가정 시 $5.28, 할인 없으면 계획값 $8.01로 완료 전 중단 가능.
- 각 데이터셋의 native When 별도 평가. AEB 책임 모듈과 Hallu 유도 발화자는 별도 보조 지표. What·joint 없음.
- 30초 heartbeat, 원본 저장·재개·청구/예약 보호. 저성능을 이유로 중단하는 gate 없음.

오프라인 확인:

```powershell
.\.venv\Scripts\python.exe -u experiments\hallu_errorbench_taxonomy\run.py --check
```

실제 실험 시작/재개:

```powershell
cd E:\taxonomy-v2
.\.venv\Scripts\python.exe -u experiments\hallu_errorbench_taxonomy\run.py --run
```

완료 시 `RESULTS_KO.md` 경로를 출력한다. `artifacts/active_run.json`에서도 실제 run 위치를 확인할 수 있다.
