"""Default/--check is offline. Only --run starts the paid frozen study."""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from experiments.hallu_errorbench_taxonomy.runner import preflight,run
from experiments.hallu_errorbench_taxonomy.runtime import StopRun


def main():
    parser=argparse.ArgumentParser(description=__doc__);group=parser.add_mutually_exclusive_group()
    group.add_argument('--check',action='store_true');group.add_argument('--run',action='store_true');args=parser.parse_args()
    try:
        print(json.dumps(run() if args.run else preflight(),ensure_ascii=False,indent=2),flush=True);return 0
    except (StopRun,OSError,ValueError) as exc:
        print(json.dumps({'status':'STOPPED','reason':str(exc)},ensure_ascii=False),flush=True);return 2


if __name__=='__main__':raise SystemExit(main())
