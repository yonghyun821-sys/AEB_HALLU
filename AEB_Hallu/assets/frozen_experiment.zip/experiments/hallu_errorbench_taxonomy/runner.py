"""One frozen, fresh bidirectional experiment. No accuracy-dependent gate."""
import importlib.metadata
import json
import os
import time
from collections import Counter
from concurrent.futures import FIRST_COMPLETED,ThreadPoolExecutor,wait

from taxonomy_experiment.config import _load_project_dotenv
from taxonomy_experiment.io import append_jsonl,read_json,write_json
from experiments.step_accuracy_v2.core import run_lock
from experiments.taxonomy_contrastive_attribution.runner import freeze_files
from experiments.taxonomy_contrastive_attribution.runtime import load_rows
from experiments.agenthallu_taxonomy_all_at_once.runner import Study as BaseStudy
from .design import ROOT,HERE,ARMS,DATASETS,sha,canonical,guidance,guide_for,messages,parse
from .runtime import Ledger,Client,Progress,StopRun,client_config
from .results import summarize

ARTIFACTS=HERE/'artifacts'


def snapshot():
    plan=read_json(HERE/'study_plan.json');prepared=HERE/'prepared'
    for name,digest in plan['hashes'].items():
        if sha((prepared/name).read_bytes())!=digest:raise StopRun('Prepared file changed: '+name)
    expected={'agenthallu':240,'agenterrorbench':171} if plan['scope']=='full' else {'agenthallu':120,'agenterrorbench':91}
    cap=8 if plan['scope']=='full' else 5
    if plan['conditions']!=list(ARMS) or plan['budget']['hard_cap_usd']!=cap or plan['cases']!=expected:
        raise StopRun('Reviewed membership/conditions/budget changed')
    inf=plan['inference']
    if (inf['model'],inf['temperature'],inf['reasoning_enabled'],inf['max_output_tokens'],inf['workers'])!=('google/gemini-2.5-flash',0,False,512,2):
        raise StopRun('Reviewed Gemini request settings changed')
    guides=guidance()[0]
    for name,text in guides.items():
        if (prepared/'guidance'/(name+'.txt')).read_text(encoding='utf-8')!=text:raise StopRun('Frozen guidance differs from source construction')
    data=load_rows(prepared/'inputs.jsonl');gold=load_rows(prepared/'gold.jsonl');manifest=load_rows(prepared/'request_manifest.jsonl')
    lookup={r['case_id']:r for r in data}
    if len(data)!=sum(expected.values()) or len(lookup)!=len(data) or Counter(r['dataset'] for r in data)!=expected or len(gold)!=len(data) or {g['case_id'] for g in gold}!=set(lookup):
        raise StopRun('Native study membership changed')
    if Counter((t['case_id'],t['arm']) for t in manifest)!=Counter({(key,a):1 for key in lookup for a in ARMS}):raise StopRun('Expected all cases x four arms')
    for task in manifest:
        record=lookup[task['case_id']]
        if task['dataset']!=record['dataset'] or sha(canonical(messages(record,guide_for(record['dataset'],task['arm'],guides))))!=task['prompt_sha256']:
            raise StopRun('Prompt hash/dataset changed')
    audit=read_json(prepared/'source_audit.json')
    for relative,digest in audit['files'].items():
        if sha((ROOT/relative).read_bytes())!=digest:raise StopRun('Pinned source changed: '+relative)
    files=[p for p in HERE.glob('*.py') if not p.name.startswith('test_')]+[HERE/'study_plan.json',HERE/'PROTOCOL_KO.md',HERE/'README.md']
    files += [p for p in prepared.rglob('*') if p.is_file()]
    files += [ROOT/p for p in audit['files']]
    files += [ROOT/p for p in ('experiments/agenthallu_taxonomy_all_at_once/design.py',
        'experiments/agenthallu_taxonomy_all_at_once/runtime.py','experiments/agenthallu_taxonomy_all_at_once/runner.py',
        'experiments/agenthallu_taxonomy_all_at_once/results.py','experiments/taxonomy_short_attribution/runtime.py',
        'experiments/taxonomy_contrastive_attribution/runtime.py','experiments/taxonomy_contrastive_attribution/prepare.py',
        'experiments/taxonomy_contrastive_attribution/runner.py','experiments/deepseek_step_relation_merge/streaming.py',
        'experiments/step_accuracy_v2/core.py','experiments/step_accuracy_v2/data.py','src/taxonomy_experiment/io.py','src/taxonomy_experiment/config.py')]
    identity={'version':'hallu-errorbench-v1','files_sha256':{p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted(set(files))},
        'packages':{name:importlib.metadata.version(name) for name in ('openai','httpx','pydantic','tiktoken')}}
    return plan,data,manifest,identity


def preflight():
    _load_project_dotenv(ROOT);plan,data,manifest,identity=snapshot();key=sha(canonical(identity));ledger=Ledger(ARTIFACTS/'ledger.jsonl',plan['budget']['hard_cap_usd'])
    if (ARTIFACTS/'active_run.json').exists() and read_json(ARTIFACTS/'active_run.json')['identity_sha256']!=key:
        raise StopRun('An active frozen study exists with different files; refusing budget reset')
    spend=ledger.summary()
    if spend['holds']:raise StopRun('Unresolved previous billing; no duplicate requests')
    return {'status':'OFFLINE_READY','cases':plan['cases'],'planned_calls':len(manifest),'new_study_hard_cap_usd':ledger.cap,
        'billed_usd':spend['billed'],'api_key_configured':bool(os.environ.get('OPENROUTER_API_KEY')),
        'model':plan['inference']['model'],'thinking_enabled':False,'paid_calls_made_by_check':0,
        'live_endpoint_validated':False,'identity_sha256':key,'forecast':plan['budget']['forecast']}


class Study(BaseStudy):
    def stage(self):
        # Two trajectories in parallel; four arms sequential within each.
        # This avoids simultaneous requests racing on the same long prefix.
        # It improves the opportunity for provider caching, without assuming it.
        batches={}
        for task in self.manifest:
            if (task['case_id'],task['arm']) not in self.rows:batches.setdefault(task['case_id'],[]).append(task)
        remaining=iter(batches.values());stopped=None
        with ThreadPoolExecutor(max_workers=2) as pool:
            pending={}
            def start_batch(batch=None):
                nonlocal stopped
                if batch is None:batch=next(remaining,None)
                if batch:pending[pool.submit(self.one,batch[0])]=batch
            for _ in range(2):start_batch()
            while pending:
                try:done,_=wait(pending,return_when=FIRST_COMPLETED)
                except BaseException as exc:stopped=exc;self.cancel.set();done=set(pending)
                follow=[]
                for future in sorted(done,key=lambda f:pending[f][0]['order']):
                    batch=pending.pop(future)
                    try:
                        row=future.result();append_jsonl(self.output/'predictions.jsonl',row)
                        self.rows[row['case_id'],row['arm']]=row;self.refresh();self.progress.emit('SAVED',message=row['case_id']+':'+row['arm'])
                        follow.append(batch[1:])
                    except BaseException as exc:
                        if stopped is None:stopped=exc
                        self.cancel.set()
                if stopped is None:
                    for batch in follow:start_batch(batch or None)
        if stopped is not None:raise stopped

    def refresh(self):
        rows=list(self.rows.values())
        self.progress.update(calls_done=len(rows),overall_done=len(rows),arms=dict(Counter(r['arm'] for r in rows)),
            datasets=dict(Counter(r['dataset'] for r in rows)),invalid_json=sum(not r['json_valid'] for r in rows),
            invalid_coordinates=sum('invalid_native_step' in (r['prediction'] or {}).get('format_issues',[]) for r in rows),
            field_issues=sum(bool((r['prediction'] or {}).get('format_issues',[])) for r in rows),
            input_tokens=sum(r['usage'].get('prompt_tokens',0) for r in rows),output_tokens=sum(r['usage'].get('completion_tokens',0) for r in rows),
            cached_tokens=sum((r['usage'].get('prompt_tokens_details') or {}).get('cached_tokens',0) for r in rows))

    def one(self,task):
        record=self.lookup[task['case_id']];prompt=messages(record,guide_for(record['dataset'],task['arm'],self.guides))
        if sha(canonical(prompt))!=task['prompt_sha256']:raise StopRun('Frozen prompt mismatch')
        worker=self.progress.worker(task['case_id']+':'+task['arm']);start=time.monotonic()
        try:
            raw,key=self.client.call(prompt,worker,self.cancel)
            row={**task,'cache_key':key,'json_valid':False,'prediction':None,'api_seconds':time.monotonic()-start,'usage':raw.get('usage') or {}}
            try:
                choice=raw['choices'][0]
                if choice.get('finish_reason')!='stop':raise ValueError('Truncated/non-stop output')
                row['prediction']=parse(json.loads(choice['message'].get('content') or ''),record);row['json_valid']=True
            except (ValueError,TypeError,KeyError,IndexError) as exc:row['parse_error']=str(exc)[:250]
            return row
        finally:worker.close()


def run():
    _load_project_dotenv(ROOT);ARTIFACTS.mkdir(exist_ok=True)
    with run_lock(ARTIFACTS/'budget.lock'):
        plan,data,manifest,identity=snapshot();key=sha(canonical(identity))
        if not os.environ.get('OPENROUTER_API_KEY'):raise StopRun('OPENROUTER_API_KEY missing from project environment/.env')
        output=ARTIFACTS/('run-'+key[:16]);active=ARTIFACTS/'active_run.json'
        if active.exists():
            if read_json(active)['identity_sha256']!=key:raise StopRun('Frozen study changed; refusing new run/budget')
        else:
            if (ARTIFACTS/'ledger.jsonl').exists():raise StopRun('Ledger without active study; refusing budget reset')
            output.mkdir(exist_ok=True);write_json(output/'identity.json',identity);write_json(active,{'identity_sha256':key,'run_directory':str(output)})
        freeze_files(identity,output)
        ledger=Ledger(ARTIFACTS/'ledger.jsonl',plan['budget']['hard_cap_usd']);client=Client(client_config(plan),output,ledger)
        frozen=output/'frozen/experiments/hallu_errorbench_taxonomy/prepared'
        data=load_rows(frozen/'inputs.jsonl');manifest=load_rows(frozen/'request_manifest.jsonl')
        guides={name:(frozen/'guidance'/(name+'.txt')).read_text(encoding='utf-8') for name in (*DATASETS,'merged')}
        progress=Progress(output,ledger,dict(Counter(t['arm'] for t in manifest)),dict(Counter(t['dataset'] for t in manifest)))
        try:
            ledger.recover(client.cache)
            study=Study(plan,data,manifest,output,client,progress,'evaluation',guides)
            client.audit_cache({client.fingerprint(messages(study.lookup[t['case_id']],guide_for(t['dataset'],t['arm'],guides)))[0] for t in manifest})
            progress.start();progress.emit('START',status='RUNNING',message='Fresh Hallu and AEB four-condition evaluation; no accuracy gate')
            study.stage();summarize(plan,data,load_rows(frozen/'gold.jsonl'),study.rows,output,ledger)
            result={'status':'COMPLETE','run_directory':str(output),'result_file':str(output/'RESULTS_KO.md'),'billed_usd':ledger.summary()['billed']}
            write_json(output/'status.json',result);progress.emit('COMPLETE',status='COMPLETE',message=result['result_file']);return result
        except BaseException as exc:
            reason=str(exc) if isinstance(exc,StopRun) else ('Interrupted; saved work retained' if isinstance(exc,KeyboardInterrupt) else type(exc).__name__+'; inspect saved logs')
            write_json(output/'status.json',{'status':'STOPPED','reason':reason});progress.emit('STOPPED',status='STOPPED',message=reason)
            raise StopRun(reason) from None
        finally:
            progress.stop.set()
            if progress.thread.is_alive():progress.close()
