"""Reuse the already exercised workspace-credit-only streaming/cache transport."""
import time
from datetime import datetime
from zoneinfo import ZoneInfo

from taxonomy_experiment.io import write_json
from experiments.agenthallu_taxonomy_all_at_once.runtime import Client,Ledger,StopRun,client_config
from experiments.taxonomy_contrastive_attribution.runtime import Progress as BaseProgress


class Progress(BaseProgress):
    def __init__(self,output,ledger,targets,dataset_targets):
        super().__init__(output,ledger,sum(targets.values()),0,0)
        self.targets=targets;self.dataset_targets=dataset_targets
        self.fields.update(datasets={},invalid_json=0,invalid_coordinates=0,field_issues=0,input_tokens=0,output_tokens=0,cached_tokens=0)

    def emit(self,event,**fields):
        with self.lock:
            self.fields.update(fields);s=self.ledger.summary();elapsed=time.monotonic()-self.started;done=self.fields['calls_done']
            if self.base_done is None:self.base_done=done
            delta=done-self.base_done;eta=f'{elapsed/delta*max(0,self.total-done)/60:.1f}m' if delta else '--'
            arms=' '.join(f'{a}={self.fields["arms"].get(a,0)}/{n}' for a,n in self.targets.items())
            datasets=' '.join(f'{d}={self.fields["datasets"].get(d,0)}/{n}' for d,n in self.dataset_targets.items())
            active=' | '.join(f'{key} {v.get("status","WAITING_API")} wait={time.monotonic()-v["started"]:.0f}s '
                f'model_chars={v.get("generated_content_chars",0)} reasoning_chars={v.get("generated_reasoning_chars",0)}' for key,v in self.workers.items())
            line=(f'[{datetime.now(ZoneInfo("Asia/Seoul")).strftime("%H:%M:%S KST")}] [{event}] '
                f'{self.fields.get("status","RUNNING")} | {done}/{self.total} {datasets} | {arms} '
                f'json_invalid={self.fields["invalid_json"]} invalid_step={self.fields["invalid_coordinates"]} | '
                f'billed=${s["billed"]:.4f} reserved=${s["reserved"]:.4f} guard=${s["guard"]:.4f}/${self.ledger.cap:g} | '
                f'tokens_in={self.fields["input_tokens"]} tokens_out={self.fields["output_tokens"]} '
                f'elapsed={elapsed/60:.1f}m ETA~{eta} | {active or self.fields.get("message","")}')
            print(line,flush=True)
            write_json(self.output/'progress.json',{**self.fields,'event':event,'elapsed_seconds':elapsed,
                'billing':{k:v for k,v in s.items() if k!='holds'},'workers':self.workers,'character_counts_are_not_tokens':True})
            with (self.output/'progress.log').open('a',encoding='utf-8') as stream:stream.write(line+'\n')
