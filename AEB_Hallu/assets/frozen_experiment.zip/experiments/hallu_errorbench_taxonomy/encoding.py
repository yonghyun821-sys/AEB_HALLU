"""Lossless, per-trajectory references for repeated long text, never summaries."""
import collections
import re


def parts(text):
    """Keep complete outer memory blocks intact; malformed wrappers stay literal."""
    spans=[];depth=0;start=0
    for match in re.finditer(r'</?memory\s*>',text,re.I):
        if match.group().startswith('</'):
            depth-=1
            if depth<0:return [text]
            if depth==0:spans.append((start,match.end()))
        else:
            if depth==0:start=match.start()
            depth+=1
    if depth or not spans:return [text]
    result=[];last=0
    for start,end in spans:
        if start>last:result.append(text[last:start])
        result.append(text[start:end]);last=end
    if last<len(text):result.append(text[last:])
    return result


def encode(value):
    counts=collections.Counter()
    def count(v):
        if isinstance(v,str):counts.update(parts(v))
        elif isinstance(v,list):
            for x in v:count(x)
        elif isinstance(v,dict):
            for x in v.values():count(x)
    count(value)
    repeated=sorted(s for s,n in counts.items() if n>1 and len(s)>=160)
    ids={s:f'T{i+1:04d}' for i,s in enumerate(repeated)}
    table={ids[s]:s for s in repeated}
    def visit(v):
        if isinstance(v,str):
            segments=parts(v)
            if not any(s in ids for s in segments):return v
            mapped=[{'text_ref':ids[s]} if s in ids else s for s in segments]
            return mapped[0] if len(mapped)==1 else {'text_parts':mapped}
        if isinstance(v,list):return [visit(x) for x in v]
        if isinstance(v,dict):return {k:visit(x) for k,x in v.items()}
        return v
    result={'text_table':table,'execution':visit(value)}
    if decode(result)!=value:raise ValueError('Lossless text-reference round trip failed')
    return result


def decode(encoded):
    table=encoded['text_table']
    def visit(v):
        if isinstance(v,dict):
            if set(v)=={'text_ref'}:return table[v['text_ref']]
            if set(v)=={'text_parts'}:return ''.join(visit(x) for x in v['text_parts'])
            return {k:visit(x) for k,x in v.items()}
        if isinstance(v,list):return [visit(x) for x in v]
        return v
    return visit(encoded['execution'])
