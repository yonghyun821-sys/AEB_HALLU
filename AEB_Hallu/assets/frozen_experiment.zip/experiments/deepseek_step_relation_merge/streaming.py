from __future__ import annotations

import asyncio
import time
import httpx

from openai import AsyncOpenAI
from openai.types.chat import ChatCompletion


class RequestDeadlineError(RuntimeError):
    pass


async def collect(client_args: dict, request: dict, *, deadline: float, progress=None) -> ChatCompletion:
    """Collect SSE as a normal completion, preserving billing and strict parsing.

    asyncio.timeout includes connection, queue, keepalives and generation. The
    deadline cancels the stream even when SSE comments prevent read timeouts.
    """
    started = time.monotonic()
    content, reasoning = [], []
    result, usage, finish = {}, None, None
    chunks, content_chars, reasoning_chars = 0, 0, 0
    try:
        async with asyncio.timeout(deadline):
            async with httpx.AsyncClient(timeout=60) as transport, AsyncOpenAI(**client_args, http_client=transport) as client:
                stream = await client.chat.completions.create(**request, stream=True, stream_options={"include_usage": True})
                async with stream:
                    async for chunk in stream:
                        data = chunk.model_dump(mode="json")
                        if data.get("error"):
                            error = data["error"]
                            raise RuntimeError(f"Provider stream error: {error.get('code', 'unknown')}: {error.get('message', '')}")
                        chunks += 1
                        for key in ("id", "created", "model", "provider", "system_fingerprint"):
                            if data.get(key) is not None:
                                result[key] = data[key]
                        if data.get("usage") is not None:
                            usage = data["usage"]
                        for choice in data.get("choices") or []:
                            if choice.get("index", 0) != 0:
                                continue
                            if choice.get("finish_reason"):
                                finish = choice["finish_reason"]
                            delta = choice.get("delta") or {}
                            text = delta.get("content") or ""
                            thought = delta.get("reasoning") or delta.get("reasoning_content") or "".join(
                                x.get("text", "") for x in delta.get("reasoning_details") or [] if x.get("type") == "reasoning.text")
                            content.append(text); reasoning.append(thought)
                            content_chars += len(text); reasoning_chars += len(thought)
                        if progress is not None and (content_chars or reasoning_chars):
                            first = not progress.state.get("stream_chunks")
                            fields = dict(status="GENERATING", stream_chunks=chunks,
                                          generated_content_chars=content_chars, generated_reasoning_chars=reasoning_chars,
                                          generation_id=result.get("id"), message="Actual model data received; character counts are not token counts")
                            if first:
                                fields["first_model_data_seconds"] = time.monotonic() - started
                                progress.emit("FIRST_MODEL_DATA", **fields)
                            else:
                                progress.update_fields(**fields)
    except TimeoutError as exc:
        raise RequestDeadlineError(f"Step request exceeded the {deadline:g}s total deadline; stream cancelled; billing remains reserved if unknown") from exc
    if not finish or finish == "error":
        raise RuntimeError("Provider stream ended without a successful terminal finish reason")
    result.update(object="chat.completion", usage=usage, choices=[{
        "index": 0, "finish_reason": finish,
        "message": {"role": "assistant", "content": "".join(content), "reasoning": "".join(reasoning)},
        "logprobs": None}])
    return ChatCompletion.model_validate(result)
